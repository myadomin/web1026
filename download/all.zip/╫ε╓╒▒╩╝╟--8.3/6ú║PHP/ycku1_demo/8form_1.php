<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  <!-- 设置HTML的页面编码为UTF-8 -->
<form method="post" action="8form.php">
	姓名：<input type="text" name="username"/><br/>
	<input type="submit" value="提交"/>
</form>


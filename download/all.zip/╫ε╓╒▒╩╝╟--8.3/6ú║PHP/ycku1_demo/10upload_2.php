<?php

$url = $_GET["url"];
echo "<img src='uploads/".$url."'/>";

?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  <!-- 设置HTML的页面编码为UTF-8 -->
<form method="post" action="8form.php">
	用户名：<input type="text" name="username"/><br/>
	密　码：<input type="password" name="password"/><br/>
	邮　箱：<input type="text" name="email"/><br/>
	验证码：<input type="text" name="code" size="5"/>1234<br/>
	介　绍：<textarea rows="6" cols="25" name="content"></textarea><br/>
	<input type="submit" name="send" value="提交"/>
</form>
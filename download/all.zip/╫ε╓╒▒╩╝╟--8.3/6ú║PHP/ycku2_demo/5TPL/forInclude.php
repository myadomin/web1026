<?php

//测试 include语句用
echo '我要被引用';

?>
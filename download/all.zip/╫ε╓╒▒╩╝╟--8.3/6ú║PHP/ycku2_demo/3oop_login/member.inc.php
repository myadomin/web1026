
<h3>个人中心</h3>
<div class="start">
	<p>欢迎您归来，<?php echo $_COOKIE["username"]?></p>  <!-- 读取cookie -->
</div>

<h3>请注册您的个人信息</h3>
<div class="reg"> 
	<form method="post" action="">
		<p>用 户 名：<input type="text" name="username" /></p>
		<p>密　　码：<input type="password" name="password" /></p>
		<p>密码确认：<input type="password" name="notpassword" /></p>
		<p>电子邮件：<input type="text" name="email" /></p>
		<p><input type="submit" name="send" value="注册" /></p>
		<p>[<a href="index.php">返回上一层</a>]</p>
	</form>
</div>
 
<h3>欢迎光临会员俱乐部</h3>
<div class="start">
	<a href="index.php?index=login">登录</a> | 
	<a href="index.php?index=reg">注册</a>
</div>



 
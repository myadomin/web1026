
<h3>请登录您的账号</h3>
<div class="login"> 
	<form method="post" action="">
		<p>用 户 名：<input type="text" name="username" /></p>
		<p>密　　码：<input type="password" name="password" /></p>
		<p><input type="submit" name="send" value="登录" /></p>
		<p>[<a href="index.php">返回上一层</a>]</p>
	</form>
</div>



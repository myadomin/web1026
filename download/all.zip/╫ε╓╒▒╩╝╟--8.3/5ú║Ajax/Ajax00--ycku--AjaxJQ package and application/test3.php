<?php
	
	echo "我是test3.php";

	echo "<br/>";

	if($_POST["name"] == "luo"){
		echo "是POST提交给我的,而且是name=luo";
	}else{
		echo "木有";
	}

	echo "<br/>";

	echo $_POST["user"]."----".$_POST["email"]."-----".$_POST["sex"];

?>
<?php
	header("Content-Type:text/html;charset=utf-8");
	
	echo "我是PHP文档<br/>";

	echo "GET部分：";
	if($_GET["name"] == "luo"){         //这里luo加不加分号都没关系
		echo "是GET方式发送我的,并且name=luo <br/>";
	}else{
		echo "可能不是GET方式发送我的,也可能是GET但是name!=luo <br/>";
	}

	echo "POST部分：";
	if($_POST["name"] == "luo"){         //这里luo加不加分号都没关系
		echo "是POST方式发送我的,并且name=luo <br/>";
	}else{
		echo "可能不是POST方式发送我的,也可能是POST但是name!=luo <br/>";
	}



?>
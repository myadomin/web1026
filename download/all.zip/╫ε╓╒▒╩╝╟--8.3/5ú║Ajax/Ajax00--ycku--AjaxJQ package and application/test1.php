<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>test1</title>
</head>
<body>

	<ul id="ul1">
	<p>我是第一个ul</p>
	<li class="li1">11</li>
	<li class="li2">12</li>
	<li class="li3">13</li>
	<li class="li4">14</li>
	<li class="li5">15</li>
	</ul>
	<ul id="ul2">
		<p>我是第二个ul</p>
		<li class="li1">21</li>
		<li class="li2">22</li>
		<li class="li3">23</li>
		<li class="li4">24</li>
		<li class="li5">25</li>
	</ul>
	
	GET提交部分输出：
	<?php  
	if($_GET["name"] == "luo"){     //如果是get方式提交过来的并且 url?name=luo
		echo "是GET方式提交给我的,并且是?name=luo";
	}else{
		echo "不是GET方式提交给我的,或者是GET但是没有?name=luo";
	}
	?>
	<br />

	POST提交部分输出：
	<?php
	//echo $_POST["age"]."<br/>";  
	if($_POST["age"] == "30"){     //如果是get方式提交过来的并且 url?name=luo
		echo "是POST方式提交给我的,并且传给我的数据是{age:30}";
	}else{
		echo "不是POST方式提交给我的,或者是POST但是传给我的数据不是{age:30}";
	}
	?>
	<br />
	
 
</body> 
</html> 
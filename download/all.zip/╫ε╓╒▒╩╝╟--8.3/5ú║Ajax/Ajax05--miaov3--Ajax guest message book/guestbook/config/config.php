<?php
/**
 * @ config.php
 * @ zmouse@vip.qq.com
 */

$_CONFIGS = array(

	'db'	=>	array(
		'db_host'		=>	'localhost',
		'db_port'		=>	'8080',
		'db_user'		=>	'root',
		'db_password'	=>	'070924',
		'db_name'		=>	'miaov_guestbook',
	),

);
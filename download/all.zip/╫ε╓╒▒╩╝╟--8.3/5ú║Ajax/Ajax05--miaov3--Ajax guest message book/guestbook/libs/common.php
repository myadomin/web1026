<?php
/**
 * @ common.php
 * @ zmouse@vip.qq.com - miaov.com
 */

//定义app基本常量
define('APP_VERSION', '1.0');

if (!defined('APP_PATH')) define('APP_PATH', substr(dirname(__FILE__), 0, -4));

define('CONFIG_APP', APP_PATH . 'config/');	//config目录
define('LIBS_PATH', APP_PATH . 'libs/');	//libs目录
define('CLASS_PATH', LIBS_PATH . 'Class/');	//class目录
define('FUNCTION_PATH', LIBS_PATH . 'Function/');	//function目录
define('CONTROLLER_PATH', APP_PATH . 'Controller/');	//控制器目录

//默认Module
define('DEFAULT_MODULE_NAME', 'Index');
//默认Action
define('DEFAULT_ACTION_NAME', 'index');

//header('Access-Control-Allow-Origin:*');//如果涉及跨域请求的话请加上这一句
header('Content-type:text/html; charset="utf-8"');

if ( version_compare(PHP_VERSION, '5.2.0', '<') ) {
	exit('PHP 版本太低了！！');
}

require(CONFIG_APP . 'config.php');

require(FUNCTION_PATH . 'common.php');

//整个程序流程 
//点击各个button ajax请求index.php?m=xxx&a=xxx&username=xxx等 不同的xxx最终输出不同的json
//$_REQUEST[]等同于包含$_GET[]及$_POST[]功能 接收get或者post过来的字符串 'm=xxx&a=xxx'  
//m的值决定了引用并实例化Controller文件夹下的那个类 这里主要是m=Index 实例化IndexController.class.php
//a的值决定了调用上面被实例化的类的哪个方法 例如注册就是a=reg 然后调用IndexController类下的reg方法
//调用reg方法后 用$_REQUEST['username']等进行注册验证 对应的不同结果传给sendByAjax()不同的参数
//在Controller.class.php中调用sendByAjax() 最终输出json

class App {

	static function run() {
		//当前module
		define('MODULE_NAME', isset($_REQUEST['m']) && !empty($_REQUEST['m']) ? $_REQUEST['m'] : DEFAULT_MODULE_NAME);
		//当前action
		define('ACTION_NAME', isset($_REQUEST['a']) && !empty($_REQUEST['a']) ? $_REQUEST['a'] : DEFAULT_ACTION_NAME);

		require_once(CLASS_PATH . 'Controller.class.php');

		//echo '当前模块：' . MODULE_NAME . '<br />' . '当前动作：' . ACTION_NAME;
		$class_name = $class_file_name = ucfirst(MODULE_NAME) . 'Controller';
		$class_file = CONTROLLER_PATH . $class_file_name . '.class.php';

		//检测控制文件是否存在
		if (!file_exists($class_file)) exit("控制器文件 $class_file 不存在!");

		require_once($class_file);

		//检测控制器类是否存在
		if (!class_exists($class_name)) exit("控制器类 $class_name 不存在!");
		$Class = new $class_name;

		//检测控制类方法是否存在
		$class_method = ACTION_NAME;
		if (!method_exists($Class, $class_method)) exit("控制器方法 $class_method 不存在!");

		//调用控制器类方法
		call_user_func(array($Class, $class_method));
	}
}

App::run();

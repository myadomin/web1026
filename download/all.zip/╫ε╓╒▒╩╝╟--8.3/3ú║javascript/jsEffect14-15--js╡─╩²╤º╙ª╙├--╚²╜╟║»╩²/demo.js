﻿//三角函数


window.onload = function(){


	//1：圆周运动函数封装 封装详情见下面
	var oDiv1 = document.getElementById('div1');
	var oDiv2 = document.getElementById('div2');
	var oDiv3 = document.getElementById('div3');
	var oBtn = document.getElementById('btn');
	var clickFlag = true;
	oBtn.onclick = function(){
		if(clickFlag){
			circularMotion(oDiv1, 300, 400, '#8E9', 8000);  //圆心500 400 轨迹颜色#809 5000毫秒走完一圈
			circularMotion(oDiv2, 300, 400, '#A38', 10000);
			circularMotion(oDiv3, 300, 400, '#591', 12000);	
		}
		clickFlag = false;
	}


	//2：会动的眼睛 数学等比应用
	var oEye1 = document.getElementById('eye1');
	var oEye2 = document.getElementById('eye2');
	var oEye1Left = parseInt(getStyle(oEye1, "left"));  //眼睛1起始位置
	var oEye1Top = parseInt(getStyle(oEye1, "top"));
	var oEye2Left = parseInt(getStyle(oEye2, "left"));  //眼睛2起始位置
	var oEye2Top = parseInt(getStyle(oEye2, "top"));

	document.onmousemove = function(ev){
		var oEvent = ev || event;
		var mouseX = oEvent.clientX;   
		var mouseY = oEvent.clientY;

		eyesMove(oEye1, mouseX, mouseY, oEye1Left, oEye1Top);
		eyesMove(oEye2, mouseX, mouseY, oEye2Left, oEye2Top);
	}

	function eyesMove(obj, mouseX, mouseY, ObjLeft, ObjTop){
		var objX = obj.offsetLeft + obj.offsetParent.offsetLeft + obj.offsetWidth/2; //眼睛坐标
		var objY = obj.offsetTop + obj.offsetParent.offsetTop + obj.offsetHeight/2;
		var diffX1 = (mouseX - objX);   //鼠标与眼睛的X轴差值 
		var diffY1 = (mouseY - objY);   //如果为负 那就影响下面的diffX2也为负
		var distance1 = Math.sqrt( Math.pow(diffX1, 2) + Math.pow(diffY1, 2) );  //鼠标与眼睛的距离
		var radius = 8;     			//眼睛可以上下左右移动最多8px
		// diffX2/radius = diffX1/distance1 = sin(xxx)   //数学推导公式
		// diffY2/radius = diffY1/distance1 = cos(xxx)   //数学推导公式
		var diffX2 = radius * (diffX1/distance1);  		 //眼睛实际X轴位置与起始X轴位置的差值 可能为负
		var diffY2 = radius * (diffY1/distance1); 

		obj.style.left =  ObjLeft + diffX2 + 'px';
		obj.style.top = ObjTop + diffY2 + 'px';
	}


	//3：模拟台球的碰撞运动 速度分解
	var oBtn2 = document.getElementById('btn2');
	oBtn2.onclick = function(){
		var oBall1  = document.getElementById('ball1');
		var oBall2 = document.getElementById('ball2');
		var oBall3  = document.getElementById('ball3');
		var oBall4 = document.getElementById('ball4');
		var oBall5 = document.getElementById('ball5');

		punk(oBall1, oBall2, 5);
		// punk(oBall1, oBall3, 5);   //左上 正确
		// punk(oBall1, oBall4, -5);  //右上 正确
		// punk(oBall1, oBall5, -5);  //右下 正确
	};

	function punk(obj1, obj2, speed){
		var TimerObj = null;
		var obj1Radius = parseInt(getStyle(obj1, "width"))/2;   //obj1半径
		var obj2Radius = parseInt(getStyle(obj2, "width"))/2;   //obj2半径
		var punkFlag = false;  	//碰撞开关
		var obj1sX = 0;    		//obj1sX等4个值 必须提升作用域到循环外面来 
		var obj1sY = 0;	 		//如果在碰上的if判断里面var他们 那么下次循环 
		var obj2sX = 0;    		//if(punkFlag){XX} 就不认识他们了
		var obj2sY = 0;
	 
		clearInterval(TimerObj);
		 
		TimerObj = setInterval(function(){
			var obj1X = obj1.offsetLeft + obj1Radius;  //obj1圆心 X坐标
			var obj1Y = obj1.offsetTop + obj1Radius;
			var obj2X = obj2.offsetLeft + obj2Radius;
			var obj2Y = obj2.offsetTop + obj2Radius;   //obj2圆心 Y坐标
			var distance = getDistance(obj1X, obj1Y, obj2X, obj2Y);

			//如果距离小于两球圆心间的距离 说明碰上了
			if( distance <= (obj1Radius+obj2Radius) ){   
				// sin(XX) = (obj2Y - obj1Y)/distance = s2/speed    //数学公式 XX代表图中的角度阿尔法
				// cos(XX) = (obj2X - obj1X)/distance = s1/speed    //数学公式
				var tmpSin = (obj2Y - obj1Y)/distance;
				var tmpCos = (obj2X - obj1X)/distance;
				//将碰撞前的速度speed 分解成速度s1 s2
				var s1 = tmpCos * speed;    	  
				var s2 = tmpSin * speed;

				//将S1 S2分别分解为横向纵向的速度 
				// cos(XX) = s1X/s1 = tmpCos;   //数学公式 XX代表图中的阿尔法
				// sin(XX) = s1Y/s1 = tmpSin;
				// sin(XX) = s2X/s2 = tmpSin;
				// cos(XX) = s2Y/s2 = tmpCos;
				var s1X = tmpCos * s1;   		//s1分解出的横向速度
				var s1Y = tmpSin * s1;   		//s1分解出的纵向速度
				var s2X = tmpSin * s2;
				var s2Y = tmpCos * s2;
				//碰撞后的obj2具备反向的s1速度和正向的s2速度 合成obj2的横向纵向速度 
				obj2sX = s2X - s1X;  		//合成的obj2的横向速度 
				obj2sY = -s2Y - s1Y;  		//合成的obj2的纵向速度

				//碰撞后 由于反作用力 obj1具备上面的s1速度  
				obj1sX = s1X;       		//obj1的横向速度
				obj1sY = s1Y;  	 		 	//obj1的纵向速度
			
				punkFlag = true;   			//碰撞了
			}

			//判断碰撞到的瞬间 上面计算出的两个球的横向纵向速度开始赋值 改变方向
			if(punkFlag){ 
				obj2.style.left = obj2.offsetLeft + obj2sX + 'px';
				obj2.style.top = obj2.offsetTop + obj2sY + 'px';
				obj1.style.left = obj1.offsetLeft + obj1sX + 'px';
				obj1.style.top = obj1.offsetTop + obj1sY + 'px';
			}else{  	 //如果没碰撞
				obj2.style.left = obj2.offsetLeft + speed + 'px'; 
			}
		}, 10);
	}


	//4：绘制sin图像
	var oBtn3 = document.getElementById('btn3');
	var oBtn3Flag = false;
	oBtn3.onclick = function(){
		//只有第一次onclick事件有效
		if(oBtn3Flag){
			return
		}
		oBtn3Flag = true;

		var oDivSin = document.getElementById('sin');
		var oDivSinLeft = parseInt(getStyle(oDivSin, "left"));
		var oDivSinTop = parseInt(getStyle(oDivSin, "top"));
		var TimerSin = null;
		var num = 0;    	//角度
		var value = 100;    //波峰放大倍数

		TimerSin = setInterval(function(){
			num++; 
			//x轴表示角度 角度每20ms加一   		 
			oDivSin.style.left = oDivSinLeft + num + 'px';
			//y轴就是x轴对应角度通过Math.sin函数算出的值 
			//sin的参数必须是弧度 num度对应的弧度就是num*Math.PI/180
			oDivSin.style.top = oDivSinTop - Math.sin(num*Math.PI/180)*value + 'px';

			//如果degree累加了361次后 关闭定时器 不再绘制曲线
			if(num == 361){       
				clearInterval(TimerSin);
			}

			//绘制轨迹 就是每次循环生成一个div 他的left top等于当次循环oDivSin的left top
			var oMarkSin = document.createElement('div');   
			oMarkSin.className = 'mark';
			oMarkSin.style.background = 'red';
			document.body.appendChild(oMarkSin);
			oMarkSin.style.left = oDivSin.offsetLeft + 'px';
			oMarkSin.style.top = oDivSin.offsetTop + 'px';

		}, 20);

	}

}



//计算两点间的距离 x1,y1代表第一个点的坐标点 y1,y2代表第二个点的坐标点
function getDistance(x1, y1, x2, y2){
	return Math.sqrt( Math.pow((x1-x2),2) + Math.pow((y1-y2),2) );
}

//获取计算后的属性
function getStyle(obj,attr){
	if(obj.currentStyle){               //IE
		return obj.currentStyle[attr];       
	}else{                              //W3C 
		return getComputedStyle(obj,false)[attr];
	}
}


//封装circularMotion的过程 ------------------------------------------
//第一步 做圆周运动的起始点位置 固定运动起始从度数0开始
/*function circularMotion(obj, centerX, centerY, time){
	var degree = 0; 			     //定义度数 
	var radian = 0;                  //定义弧度
	var flag = true;                 //开关

	var oDivCenter = document.createElement('div');  	//创建绿色小点作为圆心 测试用
	oDivCenter.className = 'center';
	document.body.appendChild(oDivCenter);
	oDivCenter.style.left = centerX - oDivCenter.offsetWidth/2 + 'px';
	oDivCenter.style.top = centerY - oDivCenter.offsetHeight/2 + 'px';

	var objX = parseInt(getStyle(obj, 'left'));  		//得到obj的left值  
	var objY = parseInt(getStyle(obj, 'top'));
	var radius = getDistance(objX, objY, centerX, centerY);  //计算出半径radius

	setInterval(function(){
		degree++;        						//当前度数 每30ms度数加1度
		radian = (degree/180)*Math.PI;     		//当前弧度
		
		// Math.cos(radian) = tmpX/radius; 		//通过sin cos得到这两个公式
		// Math.sin(radian) = tpmY/radius;      //计算出下面的tmpX tpmY

		// tmpX = Math.cos(radian)*radius; 
		// tpmY = Math.sin(radian)*radius;      

		//centerX + Math.cos(radian)*radius算出的是obj左上点 所以是obj左上点做圆周运动
		//所以再减去obj.offsetWidth/2 就是obj中心点做圆周运动了
		obj.style.left = centerX + Math.cos(radian)*radius - obj.offsetWidth/2 + 'px';  
		obj.style.top = centerY + Math.sin(radian)*radius - obj.offsetHeight/2 + 'px';

		if(degree == 361){                      //如果degree累加到361 关闭开关 不再创建oDivMark
			flag = false;
		}
		if(flag){                               //degree从1到360 每加1创建一个oDivMark 形成圆型轨迹
			var oDivMark = document.createElement('div');
			oDivMark.className = 'mark';
			document.body.appendChild(oDivMark);
			oDivMark.style.left = centerX + Math.cos(radian)*radius - oDivMark.offsetWidth/2 + 'px';  
			oDivMark.style.top = centerY + Math.sin(radian)*radius - oDivMark.offsetHeight/2 + 'px';
		}

	},time/360);

}*/

//第二步 问题分析
//但是上面的函数有一个问题 由于起始var degree=0; 所以运动点永远是从degree=0开始做圆周运动
//为了让任意点从自身位置起始做圆周运动 起始定义的degree就不能为0了 而是这个点自身的originDegree
//从上面的obj.style.left = centerX + Math.cos(radian)*radius - obj.offsetWidth/2 + 'px'; 
//可以反推导 得到求出任意点起始originRadian的公式如下
// Math.cos(originRadian) = (objX - centerX)/radius;
// originRadian = Math.acos((objX - centerX)/radius);
// originDegree = (originRadian/Math.PI)*180;    
// originDegree = ((Math.acos((objX - centerX)/radius))/Math.PI)*180; 
//由于Math.acos()本身会出现正负的情况 所以当起始点在第一第二象限的时候originDegree要取反
//所以最终要判断象限决定originDegree是否取反 改进后的函数如下
/**
 * obj代表想做圆周运动的元素 必须css中设置好定位
 * centerX 圆周运动的圆心X坐标
 * centerY 圆周运动的圆心Y坐标
 * markColor 轨迹颜色
 * time 多少毫秒走一圈
 */
function circularMotion(obj, centerX, centerY, markColor, time){
	var originDegree = 0; 			 //定义起始位置的度数 
	var degree = 0  				 //定义实际位置的度数 
	var radian = 0;                  //定义弧度
	var flag = true;                 //开关

	//创建绿色小点作为圆心 测试用
	var oDivCenter = document.createElement('div');  	
	oDivCenter.className = 'center';
	document.body.appendChild(oDivCenter);
	oDivCenter.style.left = centerX - oDivCenter.offsetWidth/2 + 'px';
	oDivCenter.style.top = centerY - oDivCenter.offsetHeight/2 + 'px';

	//得到obj的left值 计算出半径radius 
	var objX = parseInt(getStyle(obj, 'left'));  		 
	var objY = parseInt(getStyle(obj, 'top'));
	var radius = getDistance(objX, objY, centerX, centerY);  

	//设置起始位置的度数
	originDegree = ((Math.acos((objX - centerX)/radius))/Math.PI)*180  
	//当起始点在第一第二象限的时候originDegree要取反
	if(objY < centerY){
		originDegree = -originDegree;
	}
	//将起始位置度数赋值给实际位置度数 做后面的累加
	degree = originDegree;                  	

	var Timer = setInterval(function(){
		degree++       							//实际位置度数 每30ms度数加1度
		radian = (degree/180)*Math.PI;     		//实际位置弧度
		
		// Math.cos(radian) = tmpX/radius; 		//通过sin cos得到这两个公式
		// Math.sin(radian) = tpmY/radius;      //计算出下面的tmpX tpmY

		// tmpX = Math.cos(radian)*radius; 
		// tpmY = Math.sin(radian)*radius;      

		//centerX + Math.cos(radian)*radius算出的是obj左上点 所以是obj左上点做圆周运动
		//所以再减去obj.offsetWidth/2 就是obj中心点做圆周运动了
		obj.style.left = centerX + Math.cos(radian)*radius - obj.offsetWidth/2 + 'px';  
		obj.style.top = centerY + Math.sin(radian)*radius - obj.offsetHeight/2 + 'px';

		//如果degree累加了360次后 关闭开关 不再创建oDivMark
		if(degree == originDegree + 361){      
			flag = false;
		}
		if(flag){       
			//degree每加1创建一个oDivMark 形成圆型轨迹                        
			var oDivMark = document.createElement('div');
			oDivMark.className = 'mark';
			oDivMark.style.background = markColor;
			document.body.appendChild(oDivMark);
			oDivMark.style.left = centerX + Math.cos(radian)*radius - oDivMark.offsetWidth/2 + 'px';  
			oDivMark.style.top = centerY + Math.sin(radian)*radius - oDivMark.offsetHeight/2 + 'px';
		}

	},time/360);

}






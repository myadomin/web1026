﻿/*运动应用
*/


//无缝滚动  注意火狐1px  其他浏览器正常
//！！！！！！！！！！！！特别注意 1px的div边框导致程序出问题！！！！！！！！！！！！！！！！！！
//注意以后做任何无缝滚动的时候 要特别注意查看ul相对父元素div的offsetLeft
//如果父元素div有1px的边框的话 div溢出不隐藏的时候offsetLeft很正常就是0，但是一旦overflow:hidden后，
//在除了火狐以外所有浏览器还是0，可是在火狐下offsetLeft确变成-1了。
//一旦offsetLeft起始不是0那oUl.style.left = oUl.offsetLeft  + iSpeed + "px"就完全没办法执行
//所以只有在原offsetLeft上加上1px的边框 变成了oUl.style.left = oUl.offsetLeft + 1 + iSpeed + "px"
//以后做的时候先不要溢出隐藏 还按oUl.style.left = oUl.offsetLeft  + iSpeed + "px"做
//最后做完的时候 overflow:hidden 如果是火狐那oUl.style.left = oUl.offsetLeft + 父元素div边框 + iSpeed + "px"
//如果是其他那保存原样  oUl.style.left = oUl.offsetLeft + iSpeed + "px"
//要不就不加边框，那就都是oUl.style.left = oUl.offsetLeft + iSpeed + "px"
//如果硬要加边框就只有div不加边框，在div外层再套一个父级 在这个父级上加边框(这是本例的最终解决办法)
window.onload = function(){
	var oDivx = document.getElementById("div2");
	var oUl = oDivx.getElementsByTagName("ul")[0];
	var aLi = oUl.getElementsByTagName("li");
	var oBtn2 = document.getElementById("btn2");
	var oBtn3 = document.getElementById("btn3");
	
	oUl.innerHTML += oUl.innerHTML;                            		 //复制一个ul 使得新ul变成原2个ul 便于后续无缝连接
	oUl.style.width = (aLi[0].offsetWidth) * (aLi.length) + "px";  //ul宽度为单个li的宽度乘以li个数
	iSpeed = -1;
	
	oBtn2.onclick = function(){
	  iSpeed = -Math.abs(iSpeed);		               
	}
	oBtn3.onclick = function(){
	  iSpeed = Math.abs(iSpeed);		 
	}

  //alert(oUl.offsetTop);                                //！！！！！！注意以后做任何无缝滚动的时候 要特别注意查看ul相对父元素div的offsetLeft！！！！！！！
	                         
	timer = setInterval(scroll,10); 
																	
	function scroll(){                                             
		if(oUl.offsetLeft < -oUl.offsetWidth/2){             //当新ul向左走了一半的时候 后半是前半的重复 就瞬间把他拉到起始位置
			oUl.style.left = "0px";
		}
		else if(oUl.offsetLeft > 0){
			oUl.style.left = -oUl.offsetWidth/2 + "px";        //当新ul向右移动 一旦他的offseLeft大于0 也就是前半部分走到了div最左边的时候 瞬间拉回到后半部分
		}
		oUl.style.left = oUl.offsetLeft + iSpeed + "px";   	 //ul相对父元素div的offsetLeft 以及ul相对父元素div的绝对定位																														 //***************  重点注意边框 1px ************************************
	}																											 //只有在火狐下加边框1px  其他的都不用加

	oDivx.onmouseover = function(){
		clearInterval(timer);
	}
	oDivx.onmouseout = function(){
		timer = setInterval(scroll,10);
	}

}



 
 
















﻿
// 图片延迟加载
// 如果未做图片延迟加载，那页面一刷新就会加载所有的图片。 
// 而用户经常是进入页面后，只看了下首屏图片就跳转到了其他页面。
// 页面底部那些加载的图片并没被看到，所以造成了图片加载的浪费。 
// 为了避免浪费加载图片，所以使用图片延迟加载技术。
// 当用户往下拉，快看到底部某张图片的时候 才加载这些对应的图片。
// 如本DEMO所示，用firebug或chrome F12查看，一刷新进来只加载了p1.jpg p2.jpg。
// 往下拖动快到某个图片的时候，才加载p3 4 5 6 7 8 9 10.jpg。
// 实现原理：对于非首屏的图片，src个占位小图片，一旦图片快出现，就替换src为真实图片地址。
$(function(){
	//下拉 滚动条事件
	$(window).scroll(function(){
		//延迟100毫秒执行scroll事件 效果一样但是更平滑  
		setTimeout(function(){ 
			//尽量在each外面提取预存scrollTop等 如果在each内重复提取 浪费资源
			var scrollTop = $(window).scrollTop();  
			var windowHeight = $(window).height();   

			//每次scroll就循环每一张需要延迟加载的图片
			$('.dealy_load img').each(function(){
				//如果视窗高度加上滚动条高度大于此图片相对顶部偏移高度 也就是拖滚动条马上要看见图片的时候
				if((scrollTop + windowHeight) >= $(this).offset().top){
					//把图片的src替换成真正的图片地址
					$(this).attr('src', $(this).attr('xsrc'));
				}
			});
		}, 100);    
	});

});



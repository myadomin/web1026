﻿/*     
//1:按按钮弹出a 原生JS写法
//window.onload = function(){
//		oBtn1 = document.getElementById('btn1');
//		oBtn1.onclick = function(){
//				alert('a');
//		}
//}

//2：用jQuery库实现  
//首先在html title中 <script type="text/javascript" src="jquery-1.10.2.js"></script>
//记得这个链接必须在<script type="text/javascript" src="demo.js"></script>之前
//因为一开始执行demo.js的时候 就需要解析什么是$，所以先加载jQuery解析好相关定义
$(function (){
		$('#btn1').click(function(){
				alert('a');
				alert($(this).attr('value')); 
			  //必须$(this).attr ，因为$(this)才是jQuery对象（$()函数执行后就是jQuery对象），他下面才有attr方法，
			  //this.attr是不行的，this是$('#btn1')这是$(选取元素),jQuery这种下没有return出jQuery对象,依然是#btn1对象，这个对象下面是没有attr方法的
		});																			
});


//开始写自己的Vquery 
//1：window.onload的问题  也就是typeof vArg是function的时候 
//在Vquery文档中 window.onload = vArg; 可以如下写
//new Vquery(function(){alert(11)}); 
//new Vquery(function()(alert(22)));   
//实例化Vquery, 找到typeof vArg是functionv，所以 Arg = function(){alert(11)} = window.onload
//也就是相当于上面的两句等同
//window.onload = function(){alert(11)};
//window.onload = function(){alert(22)};
//而这种写法 只能加载最后一个事件，所以Vquery中不用 window.onload = vArg 而是 myAddEvent(window,'load',vArg)
//经过V的改进后 同样的这两句 就能依次输出了 但是还有一个问题 IE低版本输出顺序不一定是从上到下 先不管
new Vquery(function(){alert(11)}); 
new Vquery(function()(alert(22))); 

//2：如果typeof vArg是字符串的情况 也就是case第二个 如何选取.box #box box的测试  
//新加原型方法click的测试，用 $(vArg)代替new Vquery(vArg)等的测试
$(function(){
	$('#btn1').click(function(){    
		alert(11);
	});
	$('.aa').click(function(){
		alert(22);
	});	
	$('input').click(function(){
		alert(33);
	});
});

//3:show hidd hover css原型方法的添加测试 ，通过变化myAddEvent IE部分 让this指向正确 而不是window
$(function(){
	$('#btn2').click(function(){
		$('#div1').show();
	});
	$('#btn3').click(function(){
		$('#div1').hidd();
	});
	$('#div1').hover(function(){
		alert($('#div1').css('width'));
	},function(){
		$(this).css('background','green'); //这里$(this)的对象是实例化构造函数后的某个对象  this是经过hover原型方法到myAddEvent到对象冒充到当前的div1对象
	});
});

//4：toggle方法的添加 toggle(fn1,fn2,fn3....) 每次点击依次执行fn1 fn2...  一直点击就循环  而且多个对象下的toggle计数各种独立
//假如有4个按钮 分别是按钮a b c d ，我希望点击a后依次输出1 2 3... 再点击b后又依次输出1 2 3.. c d类似
//$(function(){
//	var count = 0;
//	aBtn = getByClass(document,'btns') 
//	for(var i=0 ; i<aBtn.length ; i++){
//		aBtn[i].onclick = function(){
//			alert(count++);
//		}
//	}
//})
//但是 以上的情况是 点击a按钮后 依次输出1 2 3后 再点击a之外其他的按钮 比如b  那就再依次输出 4 5 6 按钮之间不是独立的从0开始
//主要问题是count是全局的当aBtn[0]点击到3后，aBtn[1]再来点，这个count就是3了 为了解决这个问题 必须把count变成aBtn[i]各种的局部变量
//所以改写如下
//$(function(){
//	aBtn = getByClass(document,'btns');
//	
//	for(var i=0 ; i<aBtn.length ;i++){
//		addClick(aBtn[i]);           //这就相当于 addClick(aBtn[0]) addClick(aBtn[1])等 相当于独立执行了4次addClick函数
//	}
//	
//	function addClick(obj){       //这里就是有4个点击函数就绪  每个都是自己独立的count  这样最终就会独立从0输出
//		var count = 0;
//		obj.onclick = function(){
//			alert(count++);
//		}
//	}
//});
//所以通过上面的模式 初步写出toggle原型方法
//Vquery.prototype.toggle = function(){
//	for(var i=0 ; i<this.elements.length ; i++){
//		addToggle(this.elements[i]);
//	}
//	function addToggle(obj){
//		var count = 0;
//		myAddEvent(obj,'click',function(){
//		  alert(count++)
//		});
//	}	
//}
//这样只要一调用toggle方法 就会各个按钮独立的 都从0开始 输出 0 1 2 3
//但是我们不需要他独立输出 0 1 2 3  我们要他独立的依次执行 函数1 函数2 函数3等 那就改写如下
//Vquery.prototype.toggle = function(){   
//  _arguments = arguments;            //先用_arguments = arguments;  预存toggle的参数们  
//	for(var i=0 ; i<this.elements.length ; i++){
//		addToggle(this.elements[i]);
//	}
//	function addToggle(obj){               //用这种写法 this.elements[i]们 各种有独立的count计数 互补影响
//		var count = 0;
//		myAddEvent(obj,'click',function(){
//      _arguments[count % _arguments.length].call(obj);   //注意这里的arguments是上一行的function的参数 不是toggle函数的参数们(_arguments才是)
//      count++
//这里的意思就是不在原型方法上加入任何的参数,之后调用toggle(fn1,fn2,......fnn)随便你放多少个参数都可以
//用arguments[x]来代表是第几个参数，也就是代表着fn1 fn2...里面具体哪个函数.
//刚开始的时候count=0 也就是arguments[0],也就是fn1，点击就触发fn1  然后count++变成1了 
//如果再点击，那这时就是arguments[1],也就是fn2了，然后count++变成2了
//如果一直持续点击，那就是一直到count = arguments.length - 1 也就是一直执行到最后一个参数代表的函数fnn
//通过%的方法,如果之后还持续点击，那就开始又从fn1开始循环执行
//我们已知道 _arguments[x]代表了fn1 fn2 fn3们 但是为了便于toggle里面能运行this 而且this指向的还是被toggle的对象（也就是被onclick对象,也就是obj)
//所以把_arguments[x]变成function(){_argument[x].call(obj)}, _argument[x]还是代表了fn1这些，唯一改变的是把this指向从fn1们改成被toggle对象
//    });
//	}	
//}
//最后测试如下
$(function(){
	$(".btns").toggle(function(){alert('aa')},function(){alert('bb')},function(){alert('cc')});
});
//选取了class="btns"的4个input元素，他们各自独立的拥有自己的计数的count 及fn1 fn2 fn3 
//假如点击按钮a 他独自输出fn1 再点击再输出fn2 一直点击就一直执行fn1 fn2 fn3的循环
//假如中途停止了按钮a的点击去点击按钮b 按钮b是独立按钮a的  他第一次点击肯定是执行fn1 和之前点击的按钮b没关系 因为count计数独立

//添加attr方法 测试如下 两个参数 就是设置某个某些节点下的属性值 一个参数就是读取某些节点下的属性值 (aaa.bbb=xxx就是设置aaa节点的bbb属性为xxx)
$(function(){
	$("#btn4").click(function(){
		alert($('#txt1').attr('value'));    //只有一个参数那就是return this.elements[0][attr]; 也就是#txt1这个input的value
	});
	$('#btn5').click(function(){
		$('#txt1').attr('value','aaaaaaa');   //将#txt1这个input的value设置为aaaaaa
	})
	$('a').attr('href','http://www.163.com');  //通过这个 把所有a元素的 href属性变成了 http://www.163.com
});

//5：添加eq方法 也就是先找到某类元素 通过.eq(x) 找到这类元素的第x+1个元素
$(function(){
	$('div').eq(5).css('background','green');
})

//6：添加find方法,$('xxx').find('aaa'); 也就是先通过xxx找到某类元素，通过.find(aaa) 找到xxx里的aaa元素 可能是.aaa  aaa两种形式
$(function(){
	$('#ul1').find('.lix').css('background','red');  //id="ul1"下面的class="lix"的那些元素 也就是 1 2
	$('ul').find('.lix').css('background','green');    //也就是 1 2 3 4
	$('.olx').find('li').css('background','blue');    //class="olx"下面的所有的li  也就是7 8 9
});

//7:添加index方法  $(this).index() 就是找出自身，看自身处于兄弟节点们的第几个   
$(function(){
	$('input').click(function(){
		alert($(this).index());
	});
//	$('#btnx1').click(function(){
//		alert($('#btnx1').index());
//	})
//	$('#btnx2').click(function(){
//		alert($('#btnx2').index());
//	})
//	$('#btnx3').click(function(){
//		alert($('#btnx3').index());
//	})
//	$('#btnx4').click(function(){
//		alert($('#btnx4').index());
//	})
});

//8：用上面的方法 做个选项卡
//$(function(){ 
//  $('#tab_ul1').find('li').click(function(){              
//  	$('#tab_ul1').find('li').attr('className','');
//  	$('#tab_ul2').find('li').attr('className','');
//  	$(this).attr('className','active1');
//  	$('#tab_ul2').find('li').eq($(this).index()).attr('className','active2');
//  });
//});
//将重复的简化
$(function(){
	var oBtn = $('#tab_ul1').find('li');    //注意这里是实例化出来的对象群体 可不是类数组的元素集合 和aBtn = document.getElementsByTagName可不一样
	var oBlock = $('#tab_ul2').find('li');  //是oBtn  可不是aBtn  所以没有aBtn[i]这个东西
  oBtn.click(function(){              
  	oBtn.attr('className','');            //按钮框体对象群 全部className空 也就是清除按钮框体所有颜色
  	oBlock.attr('className','');          //内容框体对象群 全部className空 也就是内容框体全部隐藏
  	$(this).attr('className','active1');  //当前被点击对象的className设置为红色
  	oBlock.eq($(this).index()).attr('className','active2');  //内容框体对象群的第$(this).index()个对象的className设置为active2 也就是框体显示
  });								                                         //$(this).index()就是当前被点击对象（被点击按钮框体）处于兄弟节点(按钮框体们)的第几位， 
});
//9：让所有的原型方法都具备链式操作也就是 每个原型方法最终都是return this 
//也就是最终都返回实例化对象 这个实例化的对象下面有每个实例化方法
//之后就可以做 xxx.css(xxxx).hover(xxxx).attr(xxxx).find(xxx)等链式写法了

//10：让CSS方法能让jason作为参数
$(function(){
	$('#btnjson').toggle(function(){
 		$('#json').css({width:'200px',height:'200px',background:'red'}).css({border:'5px solid orange'});
	},function(){
		$('#json').css({width:'100px',height:'100px',background:'blue'});
	})
}) 

//11：添加bind方法 也就是添加事件
$(function(){
	$(document).bind('contextmenu',function(){
		alert(11);
 		return false;
	});
});
*/






































































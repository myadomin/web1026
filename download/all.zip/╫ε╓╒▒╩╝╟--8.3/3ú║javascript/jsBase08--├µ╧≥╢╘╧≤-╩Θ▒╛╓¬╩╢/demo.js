﻿//面向对象构造函数与继承

/*一：----------------------------------------------------面向对象构造函数-------------------------------------
//1：面向对象写法最初，之后会逐步演变为  构造函数形式面向对象+字面量形式面向对象  然后最终形成动态原型构造函数
var person1 = new Object();    //创建一个新对象
person1.name = 'lee';
person1.age = 30;
person1.showName = function(){
		return this.name + this.age;
}
alert(person1.name);   //lee
alert(person1.age);    //30
alert(person1.showName()); //lee30
//这种问题是 如果要创建第二个对象 就要全部重写一遍 如下 如果要创建对象person2
var person2 = new Object();    //创建另一个新对象
person2.name = 'luo';
person2.age = 20;
person2.showName = function(){
		return this.name + this.age;
}
alert(person2.name);   //luo
alert(person2.age);    //20
alert(person2.showName()); //luo20
//那能不能直接person2 = person呢  不能 因为一旦这样 就是person2和person指针指向同一片内存区域 之后对person2做的任何修改都会同样修改person

//2：为了解决上面的重复创建对象 重复添加对象属性 下面用工厂模式 属性值方法值用函数参数传递
function createPerson(name,age){      //此函数用于批量 工厂模式 生产对象 属性值方法值用参数传递 这样就不用重复写了
		person = new Object();
		person.name = name;
		person.age = age;
		person.showName = function(){
				return this.name + this.age;
		}
		return person;
}
person1 = createPerson('lee',20);
alert(person1.name);     			//lee
alert(person1.showName());			//lee20
person2 = createPerson('luo',30);
alert(person2.name);     			//luo
alert(person2.showName());			//luo30
alert(person1 instanceof Object);  //ture
alert(person2 instanceof Object);  //ture
//问题来了，所有的personX都是Object的实例化后的对象 
//所以搞不清楚每个personX到底具体是哪个实例化后的对象（例如具体是下面的Person还是Animal对象群，Person和Animal对象群都属于Object）

//3：为了解决上面的问题 采用构造函数（最终版 构造函数形式面向对象）
//不需要在函数内new出Object，后面实例化自然会new。  函数末尾不需要return出对象 
function Person(name,age){          //构造函数  首字母大写  意思就是哪类人 人对象群
		this.name = name;               //属性
		this.age = age;
		this.showName = function(){     //方法
				return this.name + this.age + '人';
		}
}
function Animal(name,age){          //构造函数  首字母大写  意思就是哪类动物 动物对象群
		this.name = name;               //属性
		this.age = age;
		this.showName = function(){     //方法
				return this.name + this.age +'动物';
		}
}
obj1 = new Person('lee',20);    //实例化 意思就是这个物体具体是哪个人 具体到哪个人对象
alert(obj1.name);     			//lee
alert(obj1.showName());			//lee20
obj2 = new Person('luo',30);
alert(obj2.name);     			//luo
alert(obj2.showName());			//luo30
obj3 = new Animal('kkk',40);    //实例化 意思就是这个物体具体是哪个动物 具体到哪个动物对象
alert(obj3.showName());     // kkk40
alert(obj3 instanceof Person);  //false
alert(obj3 instanceof Animal);  //ture  
//所以 上面的问题解决了 可以知道objX到底是Person实例化后的某个具体人对象 还是Animal实例化后的某个具体动物对象 

//4：理解值相等 但是每个实例化后的函数是不同的 他们内部的方法也是不同的 他们内部的属性也是不同的 
//因为他们属性及方法的引用地址是不同的 指向的内存区域也不同
function Person(name,age){          //构造函数  首字母大写  意思就是哪类人 人对象群
		this.name = name;               //属性
		this.age = age;
		this.showName = function(){     //方法
				return this.name + this.age + '人';
		}
}
person1 = new Person('lee',20);
person2 = new Person('lee',20);
//alert(person1.name == person2.name);   //ture   因为值都是lee  所以相等
//alert(person1.showName() == person2.showName()); //ture  因为值都是 lee20 所以相等
alert(person1.showName == person2.showName);  //false 这里比较的是函数的引用地址 是不同的
alert(person1 == person2);  //这里比较了这两个实例化后的变量 比较的是变量引用地址 也是不同的
//也就类似于 两个人 都叫lee 都是20岁  但是他们两个人不相等 他们两个的lee和20的意义不同 他们两个做同一件事情样子也不一样

//5：原型属性 原型方法  对比之前的实例属性 实例方法
//一个构造函数创建后,如果花括号内放入了属性和方法，就是实例属性和实例方法，
//每次new实例化出一个新对象后，这些实例属性和实例方法都会开辟一片新的内存区域放这个新对象的实例属性和实例方法
//所以每个不同的新对象，他们的指针指向是不同的，内存区域是不同的。
//而存在于不同内存区域的每个不同的新对象，他们都会有一个__proto__指针，这个指针指向同一片内存区域。
//在这个内存区域里,用于放置构造函数的原型属性和原型方法，这些原型属性和原型方法可以给每个new实例化出的新对象共用。
//所以如果花括号内任何实例属性和实例方法都没有的情况下，这些new实例化出的新对象可以用原型属性和原型方法。
//如果new实例化出的新对象有实例属性或者实例方法，这些也可以和原型属性原型方法一起拥有，访问的话优先访问实例
function Person(){};   //没放任何实例属性方法 之后new出来的新对象 只拥有原型属性方法 大家共有。
Person.prototype.name = 'lee';   //放在花括号外面的  原型属性原型方法
Person.prototype.age = 20;
Person.prototype.showName = function(){
		return this.name + this.age + '人';
}
person1 = new Person();
//alert(person1.name);   //'lee' 没有实例name属性 但是有原型name属性 所以也可以访问到person1新对象的name属性
person1.name = 'luo'; 
person2 = new Person();
//alert(person1.showName == person2.showName);   //true 说明他们的方法指针指向同一块区域  确实他们的方法都是原型方法 确实是共有的同一片内存区域的原型方法
//var obj = new Object();
//alert(Person.prototype.isPrototypeOf(obj));   //Person构造函数有原型 并实例化出obj了吗 false
//alert(Person.prototype.isPrototypeOf(person1)); //Person构造函数有原型 并实例化出person1了吗  ture
alert(person1.name);   // luo  因为定义过实例属性 person1.name = 'luo';  有实例先访问实例
alert(person1.hasOwnProperty('name'));  //true 判断person1对象是否有实例属性name
alert(person2.hasOwnProperty('name'));  //false  person2对象没有实例属性name
alert('name' in person2)  // ture  in的意思是 无论实例还是原型 只要其中一个有属性name就true 所以for in函数结合数组赋值用来继承原型方法

//6：使用字面量的方式 创建原型对象
function Person(){};
Person.prototype = {       //花括号就相当于创建了一个新Object内存区域 在这个内存区域下放了原型 而不是在Person原型内存区域   
		constructor:Person,    //强制Person构造函数的指针指向Person构造函数放原型的内存区域 
		name:'lee',            //如果不加 下面new实例化的新对象指针就会指向  Object内存区域了 不再指向构造函数Person放原型的内存区域了
		age:20,
		showName:function(){
				return this.name + this.age + '人';
		}
}
person1 = new Person();
//alert(person1.name);  //lee  
alert(person1.constructor);  //  function  Object() {[native code]}  指针指向了另外的Objec对象了 而不是Person构造函数了
//问题出现了 一旦用字面量来表示Person.prototype  那写上 ={}的过程就是创建了一个新Object  
//之后Person构造函数就开始指向这个新Object的内存区域了，而不是指向放Person原型的内存区域了
//为了让实例化出的新对象们依然指向Person构造函数本该放原型的内存区域  
//所以 在字面量第一句就加上  constructor = Person;  就是让Person构造函数重新指向 本该构造函数放在原型的内存区域
//之后实例化出的新对象 就指向了本该Person放原型的内存区域了

//7：字面量方式创建的原型对象的问题 
function Person(){};
Person.prototype = {
		constructor:Person,
		name:'lee',
		age:20,
		family:['哥哥','姐姐','妹妹'],
		showName:function(){
				return this.name + this.age +'人';
		}
}
var person1 = new Person();   //问题1 无法传参 所以内部属性值方法值没法改变
alert(person1.family);
person1.family.push('弟弟');  //在对family数组push进 弟弟  也就是原型属性数组被改变
alert(person1.family);
var person2 = new Person();
alert(person2.family);        //之后实例化的person2 也共享了被改变后的原型数组属性 所以 打印的是哥哥,姐姐,妹妹，弟弟
//结论，字面量创建的原型对象 1没办法传参   2所有的属性和方法都会被共享(任何方式创建的原型对象都有此特性)。
//为了既能传参数，又能该共享的共享，该独立的独立，
//属性部分用构造函数创建实例属性，这样属性会独立，又能传参数
//方法部分用字面量方式创建原型方法，这样方法能共享。
//最终，我们采用下面的混合模式。

//8：混合模式
function Person(name,age){
		this.name = name;
		this.age = age;
		this.family = ['哥哥','姐姐','妹妹']
}
Person.prototype = {
		constructor:Person,
		showName:function(){
				return this.name + this.age +'人';
		}
}
var person1 = new Person('luo',30);   //问题1 无法传参 解决
alert(person1.family);
person1.family.push('弟弟');  //在对family数组push进 弟弟  只对实例属性变化 与之后实例化的新对象不共享
alert(person1.family);        //数组被push进 弟弟
var person2 = new Person('lee',20);
alert(person2.family);       // 因为上个对象和我这个对象不共享数组的实例属性 所以我这里还是 哥哥,姐姐,弟弟  问题2解决
alert(person1.showName());   //luo30
alert(person2.showName());   //lee20
alert(person1.showName == person2.showName); //true 说明方法是共享的 指针指向同一个内存 节省了资源

//9：最终版：动态原型模式  更好的封装性 全部封装到一个函数里
function Person(name,age){
		this.name = name;
		this.age = age;
		this.family = ['哥哥','姐姐','妹妹']
		//将混合模式的字面量方式原型方法 放到构造函数里 用构造函数原型方法 原来的constructor:Person,也没必要了 因为是构造函数 不是字面量形式
    if(Person.prototype.showName == null){       //由于原型方法只需要new第一个新对象的时候执行一次就行 之后新对象都是共用方法的 
				Person.prototype.showName = function(){  //所以第一次执行判断肯定是null就执行一次 之后肯定都是function就不执行了
						return this.name + this.age +'人';
				}	
		}
}
var person1 = new Person('luo',30);        
var person2 = new Person('lee',20);
alert(person1.showName());
alert(person2.showName());
alert(person1.showName == person2.showName);
*/




/*二：----------------------------------------------------面向对象继承-------------------------------------
//1：原型链继承    
function Person(){      //父函数
		this.name = 'luo';
}
//Person.prototype.name = 'lee';
function Worker(){      //子函数
		this.job = 'coder';
} 
Worker.prototype = new Person();   //原型链继承 子函数继承父函数 又不影响父函数

worker1 = new Worker();
alert(worker1.name);    					 //luo 子函数Worker继承了父函数Person的name属性 如果有实例属性就打印实例属性luo 没有就打印原型属性 lee
person1 = new Person(); 
alert(person1.job);     					 //undefined 子函数并没有影响到父函数 父函数还是没有job属性
alert(worker1 instanceof Worker)   //ture
alert(worker1 instanceof Person);  //ture
//但是 这种方式 没办法传参数 所以有如下对象冒充方式

//2：对象冒充继承 call apply  可以传参了
function Person(name,age){
		this.name = name;
		this.age = age;
}
Person.prototype.showName = function(){
		return this.name + this.age +'人';
};
function Worker(name,age,job){                //对象冒充 继承 
		Person.call(this,name,age);      //Person.call(this,name,age);的意思就是将Person(name,age)的对象改为this（this在这里就是子函数Worker）
		//Person.apply(this,[name,age]); //同时将Person(name,age)执行后的结果（也就是this.name = name;this.age = age;）完全复制到这里来
		//Person.apply(this,arguments);
		this.job = job;
}
person1 = new Person('luo',30,'coder');
worker1 = new Worker('luo',30,'coder');
alert(worker1.job);   //coder
alert(worker1.name);  //luo  说明继承了name属性
alert(worker1.showName());   //worker1.showName is not a function  说明对象冒充只能继承实例属性和方法 不能继承原型属性和方法 
//为了传参 必须把属性放入构造函数  属性这部分就用对象冒充继承
//而方法因为只需要用一次 所以要把他放在原型 也就是构造函数外面 这部分对象冒充继承不到 所以用原型链继承
//最终为了满足上面的两点，下面使用混合模式

//3：组合模式继承
//属性放入构造函数，属性用对象冒充继承
//方法放入原型，方法用原型链继承 (缺点：会抹去子函数原有的方法)
function Person(name,age){
		this.name = name;
		this.age = age;
}
Person.prototype.showName = function(){
		return this.name + this.age +'人';
};

function Worker(name,age,job){    	//子函数属性用对象冒充继承
		Person.call(this,name,age);
		this.job = job;
}
Worker.prototype.showJob = function(){   //子函数自身的方法
		return '我的工作是：'+ this.job;
}
Worker.prototype = new Person();  	//子函数方法用原型链继承

person1 = new Person('luo',30);
worker1 = new Worker('luo',30,'coder');
alert(worker1.job);         //coder
alert(worker1.name);        //luo  说明子函数继承了父函数的name属性
alert(worker1.showName());  //luo30人 说明子函数继承了父函数的showName方法
alert(worker1.showName == person1.showName)  //true  说明子函数方法完全继承了父函数方法
alert(worker1.showJob());   //假如子函数本身就有一个原型方法showJob 如果用原型链继承 子函数原有的showJob方法会被抹掉 所以这句打印是 没有showJob函数
//缺点，用原型链继承方法，会抹去子函数原有的方法


//4：最终版本   完全等同于面向对象拖拽继承的例子（具体参考面向对象拖拽继承）
//属性用对象冒充继承
//方法用for i 赋值类数组继承   
function Person(name,age){
		this.name = name;
		this.age = age;
}
Person.prototype.showName = function(){
		return this.name + this.age +'人';
};

function Worker(name,age,job){       		 //子函数属性用对象冒充继承
		Person.call(this,name,age);
		this.job = job;
}
Worker.prototype.showJob = function(){   //子函数自身的方法
		return '我的工作是：'+ this.job;
}

for(i in Person.prototype){              //子函数方法用for i 赋值类数组继承   
		Worker.prototype[i] = Person.prototype[i];  //Person.prototype本身就是类数组 for i 赋值类数组 
}                                               //为什么不能Worker.prototype = Person.prototype ？因为这样指针指向同一地址了 子函数方法会影响到父函数

person1 = new Person('luo',30);
worker1 = new Worker('luo',30,'coder');

alert(worker1.name);        //luo  说明子函数继承了父函数的name属性
alert(worker1.job);         //coder 说明子函数自身的属性job也在
alert(person1.job);         //undefined 说明属性部分 子函数job属性没有影响到父函数 父函数没有job属性 
														//最终  属性部分完全没问题了！！！！！
alert(worker1.showName());  //luo30人 说明子函数继承了父函数的showName方法
alert(worker1.showJob());   //我的工作是：coder  说明子函数自身的方法也在
alert(person1.showJob());   //person1.showJob is not a function 说明子函数showJob方法没有影响到父函数 父函数没有showJob方法 方法部分完全没问题了！！ 												
*/




//改写面向过程程序为面向对象程序的步骤如下:
//1：原函数不能有函数套函数，将被嵌套的函数全部提取出来。
//2：将局部变量全部改成全局变量
//3：将变量全部变成构造函数this下的属性.
//4：将提取出来的函数全部变成原型方法
//5：this指向混乱 特别事件函数及定时器函数 通过某个作用域先存_this=this 再将_this放入其他作用域






































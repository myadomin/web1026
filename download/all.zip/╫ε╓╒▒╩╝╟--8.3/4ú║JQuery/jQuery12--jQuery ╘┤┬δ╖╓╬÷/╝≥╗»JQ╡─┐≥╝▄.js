// JavaScript Document

(function(){
	
	√(21 , 94) 定义了一些变量和函数 jQuery = function(){};
	
	√(96 , 283) 通过jQuery.fn=jQuery.prototype={xxx} 给jQuery添加一些实例方法和属性 后续调用$(xx).xxx();
	
	√(285 , 347) extend : 定义jQuery及jQuery.fn的对象扩张方法extend 
	后续扩展工具方法就用jQuery.extend({xxx}) 扩展实例方法就用jQuery.fn.extend({xxx})
	
	(349 , 817) 通过jQuery.extend({xxx}) 给jQuery扩展一些工具方法 后续调用$.xxx();
	
	(877 , 2856)  Sizzle : 复杂选择器的实现 
	
	(2880 , 3042) Callbacks : 回调对象 通过$.Callbacks = function(){return self}实现 
	所以$.Callbacks()就等于return出来的self对象 self对象下有很多方法
	
	(3043 , 3183) Deferred : 延迟对象 通过$.extend({Deferred:function(){return deferred}})实现
	所以$.Deferred()就等于return出来的deferred对象 deferred对象下有很多方法
	通过$.extend({when:function(){return deferred.promise()}})实现
	所以$.when()就等于return出来的deferred.promise()对象 所以when可以传入多个延迟对象同时操作
	
	(3184 , 3295) support : 功能检测
	
	(3308 , 3652) data() : 数据缓存
	
	(3653 , 3797) queue() : 队列方法 : 执行顺序的管理 
	
	(3803 , 4299) attr() prop() val() addClass()等 : 对元素属性的操作
	
	(4300 , 5128) on() trigger() : 事件操作的相关方法
	
	(5140 , 6057) DOM操作 : 添加 删除 获取 包装 DOM筛选
	
	(6058 , 6620) css() : 样式的操作
	
	(6621 , 7854) 提交的数据和ajax() : ajax() load() getJSON()
	
	(7855 , 8584) animate() : 运动的方法
	
	(8585 , 8792) offset() : 位置和尺寸的方法
	
	(8804 , 8821) JQ支持模块化的模式
	
	(8826)  window.jQuery = window.$ = jQuery;
	
})();


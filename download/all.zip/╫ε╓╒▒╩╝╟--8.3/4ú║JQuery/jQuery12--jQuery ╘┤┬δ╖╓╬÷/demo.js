﻿//jQuery源码分析
$(function(){


//一：JQ最外层 匿名函数自我执行 创建JQ私有作用域
(function( window, undefined ){	

	//JQ代码。。。。。
	//下面的这些变量及函数外部是访问不到的 这些变量及函数也不污染外部
	var a = '我是jquery里的某个变量';
	function showA(){
		alert('我是jquery里的某个方法');
	}
	var jQuery = function(){
		showA();
		alert(a);
	};
	//然后把jQuery及$挂在外部传参进来的window下 只有通过调用jQuery或者$才能调用函数及变量
	window.jQuery = window.$ = jQuery;

})(window);		
// showA();		//调用不到
jQuery();		//可以调用
$();			//可以调用

为什么匿名函数的参数要接收window参数的传参？
1：JS中查找作用域是从最内层往最外层找 window作用域是最外层作用域 所以查找window作用域是最慢的
为了提高查找到window的速度 这里直接传入window参数 让匿名函数接收这个window参数
之后私有作用域内使用window就直接查找匿名函数参数window 而不是去查找外部window 从而提高了查找速度
2：利于压缩版本，压缩后匿名函数的参数window可以写成任意值 只要与私有作用域内保持一致就可以

为什么匿名函数还有一个undefined参数？
undefined在IE6-7等某些浏览器下 不是系统保留字 可以随便定义 如下
var undefined = xxx; 在IE67下 undefined就变成xxx了 为了避免外部改变undefined然后传入JQ私有作用域
直接在匿名函数参数中写上undefined 之后在私有作用域内部调用undefined就直接查找的是参数undefined




//二：JQ的大致框架
(function(){
	
	√(21-94) 定义了一些变量和函数 包括jQuery = function(selector, context){xxx};
	
	√(96-283) 通过jQuery.fn=jQuery.prototype={xxx}给jQuery添加一些实例方法和属性 后续调用$(xx).xxx();
	
	√(285-347) extend : 定义jQuery及jQuery.fn的对象扩张方法extend 
	后续扩展工具方法就用jQuery.extend({xxx}) 扩展实例方法就用jQuery.fn.extend({xxx})
	
	(349-817) 通过jQuery.extend({xxx}) 给jQuery扩展一些工具方法 后续调用$.xxx();
	
	(877-2856)  Sizzle : 复杂选择器的实现 
	
	(2880-3042) Callbacks : 回调对象 通过$.Callbacks = function(){return self}实现 
	所以$.Callbacks()就等于return出来的self对象 self对象下有很多方法
	
	(3043 -3183) Deferred : 延迟对象 通过$.extend({Deferred:function(){return deferred}})实现
	所以$.Deferred()就等于return出来的deferred对象 deferred对象下有很多方法
	再通过$.extend({when:function(){return deferred.promise()}})
	所以$.when()就等于return出来的deferred.promise()对象 所以when可以传入多个延迟对象同时操作
	
	(3184-3295) support : 功能检测
	
	(3308-3652) data() : 数据缓存
	
	(3653-3797) queue() : 队列方法 : 执行顺序的管理 
	
	(3803-4299) attr() prop() val() addClass()等 : 对元素属性的操作
	
	(4300-5128) on() trigger() : 事件操作的相关方法
	
	(5140-6057) DOM操作 : 添加 删除 获取 包装 DOM筛选
	
	(6058-6620) css() : 样式的操作
	
	(6621-7854) 提交的数据和ajax() : ajax() load() getJSON()
	
	(7855-8584) animate() : 运动的方法
	
	(8585-8792) offset() : 位置和尺寸的方法
	
	(8804-8821) JQ支持模块化的模式
	
	(8826)  window.jQuery = window.$ = jQuery;
	
})();




//三：(21-94) 初始定义的部分变量及函数
1：(21-26) var rootjQuery, readyLis,
简写方式，等同于 var rootjQuery = null; var readyLis = null;  
在之后定义了rootjQuery = jQuery(document); rootjQuery就是document对象。
readyList先声明 之后会用于DOM加载。


2：(30) core_strundefined = typeof undefined,
typeof undefined就等同于'undefined'字符串，那为什么要定义core_strundefined = 'undefined'呢？
因为标准浏览器中判断一个变量a是否定义，用window.a == undefined判断就可以了。
但是在IE6-9中这个判断不准确，为了兼容统一用typeof window.a == 'undefined'来判断a是否定义。
所以这里先定义变量core_strundefined为'undefined'字符串，后续用于判断调用。


3：(38-41) _jQuery = window.jQuery, _$ = window.$,
假如在引入JQ之前我们定义了jQuery=xx1 $=xx2 这两句就把xx1预存到_jQuery xx2预存到_$
后续还想找到xx1及xx2就去_jQuery和_$里找，具体的使用见后续的工具方法$.noConflict()。


4：(44-58) 详细分析
class2type = {},
core_deletedIds = [],
core_version = "2.0.3",
core_concat = core_deletedIds.concat,
core_push = core_deletedIds.push,
core_slice = core_deletedIds.slice,
core_indexOf = core_deletedIds.indexOf,
core_toString = class2type.toString,
core_hasOwn = class2type.hasOwnProperty,
core_trim = core_version.trim,
代码的功能就是
通过class2type = {} 得到core_toString = {}.toString 再通过call实现类对象具备对象toString方法
通过core_deletedIds = [] 得到core_slice = [].slice 再通过call实现类数组具备数组slice方法


5：(61-64) 起始入口$(xxx)
jQuery = function( selector, context ) {
	return new jQuery.fn.init( selector, context, rootjQuery );
},

一般我们写面向对象构造函数的时候如下
function jQuery(){

}
jQuery.prototype.init = function(){

}
jQuery.prototype.css = function(){

}
new jQuery().css();
这样我们才能调用css方法

假如改写如下
function jQuery(){
开始执行		return new jQuery.fn.init();			//(61-64)写法
等同于			return new jQuery.prototype.init();		//见(96) 这样就执行了init方法
然后返回对象	jQuery.prototype.init.prototype;
等同于返回对象	jQuery.prototype;						//结合(96)(283)得到的结果
这样就return出了jQuery.prototype原型对象 在jQuery.prototype下是有css方法的
}
jQuery.prototype.init = function(){

}
jQuery.prototype.css = function(){

}
真正使用JQ的时候是这样调css方法的 一旦开始执行jQuery() 进入上面的jQuery函数
jQuery().css();   

(96)(283) 如下
jQuery.fn = jQuery.prototype; (96)
jQuery.fn.init.prototype = jQuery.fn; (283)
所以得到jQuery.prototype.init.prototype = jQuery.prototype


6: (67-94) 
core_pnum = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,  	数字处理
core_rnotwhite = /\S+/g,  		将一个单词的各个字母用空格分隔开
rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,  		匹配<p>aaa #div1等
rsingleTag = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,  匹配<p></p> <div></div>闭合标签
rmsPrefix = /^-ms-/,  			IE相比下面比较特殊 -ms-margin-left要转换为MsMarginLeft形式
rdashAlpha = /-([\da-z])/gi,  	把-webkit-margin-left等转换为webkitMarginLeft形式
fcamelCase  	转驼峰式写法的回调函数 后面详细解释
completed	  	DOM加载时的回调函数 后面详细解释




//四：(96-283) 2：初始定义的部分实例方法及属性。
1：大概结构
jQuery.fn = jQuery.prototype = {	
	jquery: 版本,
	constructor: 修正指向,
	init(): 初始化和参数管理,
	selector: 存储选择字符串,
	length: this对象的长度,
	toArray: 转数组,
	get(): 返回原生对象,
	pushStack: JQ对象的入栈,
	cach(): 遍历集合,
	ready(): DOM加载的接口,
	slice(): 集合的截取,
	first(): 元素集合的第一项,
	last(): 元素集合的第二项,
	eq(): 元素集合的指定项,
	map(): 返回新集合,
	end(): 返回集合前一个状态,
	push(): (内部使用),
	sort(): (内部使用),
	splice(): (内部使用)
}


2：(100) constructor:jQuery, 为什么要重新修正constructor？
正常情况下 我们这样写构造函数 不需修正constructor
function Aaa(){
	 
};
Aaa.prototype.name = 'luo';
var a1 = new Aaa();
alert(a1.constructor);  	//function Aaa(){}，不许修正，正确。

在下面的情况下 需要修正constructor
function Bbb(){
	 
};
Bbb.prototype = {			//这是一个对象赋值给了Bbb.prototype 所以constructor指向变化了
	name: 'adomin',			//这种情况下就要重新指向constructor
	//constructor: Bbb    	//如果开启这句修正后 就变回正确的function Bbb(){}
	//所以说在100行要constructor: jQuery, 重新修正constructor为jQuery
}
var b1 = new Bbb();
alert(b1.constructor);  	 


3：(101) init: function( selector, context, rootjQuery ) {xxx}
通过源码的(96)(283)分析
jQuery.fn = jQuery.prototype; (96)
jQuery.fn.init.prototype = jQuery.fn; (283)
所以jQuery.prototype.init.prototype = jQuery.prototype
所以调用jQuery.prototype.init下的原型方法(101行) 就是调用jQuery下的原型方法$(xxx)
也就是说$(xxx)就开始执行101行init定义的函数 然后$(xx) 


4：(105-194) iinit:function(selector, context, rootjQuery){xxx}具体分析 
if ( !selector ) {
	// 情况1：没定义selector 返回jQuery对象
	return this; 
}
if ( typeof selector === "string" ) {
	// 情况2：selector是字符串 详见(105-174)分析 
	return xx;
} else if ( selector.nodeType ) {
	// 情况3：selector是DOM节点 例如$(document)之类
	// this = {0:selector, length:1} 然后返回this 
	this.context = this[0] = selector;
	this.length = 1;
	return this;
} else if ( jQuery.isFunction( selector ) ) {
	// $(function(){xxx}) 调用ready方法 文档加载 
	return rootjQuery.ready( selector );
if ( selector.selector !== undefined ) {
	// $($('#div1'))之类的写法 重新变回$('#div1')
	this.selector = selector.selector;
	this.context = selector.context;
}
// 最终所有其他的情况 $([xxx]) $({xxx})等情况
// makeArray对内使用 让这些selector变成 this={0:[xxx], length:1}
return jQuery.makeArray( selector, this );
},


5：(105, 174) 分析情况2：字符串
if ( typeof selector === "string" ) {
	if ( selector.charAt(0) === "<" && selector.charAt( selector.length - 1 ) === ">" && selector.length >= 3 ) {
		// 第一个字符是< 最后一个字符是> 并且至少3个字符 那说明是HTML标签 
		// 例如$('<li>')或者$('<li>1</li><li>2</li>')等情况
		// 情况1：$('<li>')。得到数组match = [ null, '<li>', null ]; 
		// 情况2：$('<li>1</li><li>2</li>')。得到数组match = [ null, '<li>1</li><li>2</li>', null ];
		match = [ null, selector, null ];

	} else {
		// 其他的情况 例如$('#div1')或$('.div1')或$('div')或$('#div1 div.box')或$('<li>hello')等
		// (75)定义了rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
		// 意思就是匹配<字母一个或多个>作为第一个子项，或者#(字母一个或多个)作为第二个子项
		// 注意最外围的(?:xxx) 所以最外围的不算作匹配结果的子项
		// RegExp.exec(str)返回数组[a,b,c...] a是str b是匹配到的第一个子项 c是匹配到的第二个子项
		// 情况3：$('<li>hello')通过exec方法后得到数组 match = ['<li>hello', '<li>', null]
		// 情况4：$('#div1')通过exec方法后得到数组 match = ['#div1', null, 'div1']
		// 情况5：$('.div1') $('div') $('#div1 div.box')等其他 match = null;
		match = rquickExpr.exec( selector );
	}

	//通过上面形成的5种情况 开始if else
	if ( match && (match[1] || !context) ) {
		// 这个if判断 match必须存在 并且match[1]存在或者没有上下文context
		// 那就对应下面 
		// 情况1：$('<li>') match存在并且match[1]存在  
		// 情况2：$('<li>1</li><li>2</li>') match存在并且match[1]存在  
		// 情况3：$('<li>hello') match存在并且match[1]存在   
		// 情况4：$('#div1') match存在 并且没有上下文context 因为id后面肯定没上下文
		if ( match[1] ) {
			// 同时这里还要求match[1]存在 
			// 情况1：$('<li>') match存在并且match[1]存在  
			// 情况2：$('<li>1</li><li>2</li>') match存在并且match[1]存在  
			// 情况3：$('<li>hello') match存在并且match[1]存在  

			// context选取
			// $('<li>', document)就选取:context
			// $('<li>', $(document))就选取context[0]
			context = context instanceof jQuery ? context[0] : context;

			// merge对外的方法只能两个参数都是数组 
			// 把第二个参数数组合并到第一个参数数组里  
			// 而这里的merge是对内方法 
			// 对内方法可以将第二个参数jQuery.parseHTML(xx)得到的数组合并到第一个this里去
			// 例如jQuery.merge(this, ['<li>1</li>', '<li>2</li>']);
			// 最终this = {0:'<li>1</li>', 1:'<li>2</li>', length:2} 在147行 return this
			jQuery.merge( this, jQuery.parseHTML(
				// $.parseHTML工具方法的意思就是把HTML str转换成数组
				// 情况1：$('<li>') match[1] = '<li>'
				// 情况2：$('<li>1</li><li>2</li>') match[1] = '<li>1</li><li>2</li>' 
				// 情况3：$('<li>hello') match[1] = '<li>'
				// 假如下面的match[1] = '<li>1</li><li>2</li>'
				// 那就是jQuery.parseHTML('<li>1</li><li>2</li>', document, true) = ['<li>1</li>', '<li>2</li>'];
				// true的意思就是'<script></script>'也有效 因为script前的/加上了转义\
				match[1],
				context && context.nodeType ? context.ownerDocument || context : document,
				true
			) );

			// $('<li>', {title:'hi', html:'aaa'})这种情况 也满足match存在并且match[1]存在  
			// 并且带第二个添加json属性参数{title:'hi', html:'aaa'}
			if ( rsingleTag.test( match[1] ) && jQuery.isPlainObject( context ) ) {
				// 遍历上面的{title:'hi', html:'aaa'}这个json
				for ( match in context ) {
					// 如果jQuery.html()这个方法有 那就是jQuery.html('aaa');
					if ( jQuery.isFunction( this[ match ] ) ) {
						this[ match ]( context[ match ] );

					// 如果jQuery.title()这个方法没有 那就是jQuery.attr(title, 'hi');
					} else {
						this.attr( match, context[ match ] );
					}
				}
			}

			return this;

		// 情况4：$('#div1') match存在 并且没有上下文context 但是match[1]不存在 
		} else {
			// id获取元素 match[2] = 'div1' elem = document.getElementById('div1');
			elem = document.getElementById( match[2] );

			// 形成this = {0:elem, length:1}最终return this
			// if(elem && elem.parentNode)是为了兼容黑莓4.6
			if ( elem && elem.parentNode ) {
				this.length = 1;
				this[0] = elem;
			}

			this.context = document;
			this.selector = selector;
			return this;
		}

	// 情况5：$('.div1') $('div') $('#div1 div.box')等其他 match = null; 
	// context上下文必须未指定或者是jQuery对象
	} else if ( !context || context.jquery ) {
		// 通过find调用sizzle进行处理
		// 这里context上下文必须未指定 通过!context进入这里 例如$('ul').find('li')
		// 或者coentext是jQuery对象 通过context.jquery进入这里 例如$('ul', $(document)).find('li');
		return ( context || rootjQuery ).find( selector );
	//如果context上下文指定了并且不是jQuery对象 例如$('ul', document).find('li');
	} else {
		//那走这个else 并且把指针修正到jQuery对象然后调用find
		return this.constructor( context ).find( selector );
	}


6：为什么init下最终return的this都是{0:xx, 1:xx, 2:xx..., length:xx}的json形式
$(xx)开始调用init方法 return的{0:xx, 1:xx, 2:xx..., length:xx}这个json就存储了各个DOM元素
而之前已分析过$(xx)调用init也同时具备了jQuery下的原型方法 所以可以开始$(xx).css()
开始$(xx).css() 遍历操作存储了各个DOM元素的json 给这些DOM元素进行css操作
css等实例方法最终继续return出jQuery对象 之后又能继续连缀


7：(202-280) 继续给jQuery.fn=jQuery.prototype添加实例方法 后续调用$(xx).xx() 
toArray: function() {
	//[].slice.call(this) 把this冒充为数组 并slice
	return core_slice.call( this );
},

get: function( num ) {
	return num == null ?
		// 如果num参数是空 返回一个原生类数组集合 
		// 例如$('div').get()就相当于var aDiv = document.getElementsByTagName('div')
		this.toArray() :
		// 如果num是-1之类的就是原生类数组集合的倒数第一个元素对象
		// num是2之类的就是原生类数组集合的第二个原生对象
		( num < 0 ? this[ this.length + num ] : this[ num ] );
},

pushStack: function( elems ) {
	//入栈操作
	var ret = jQuery.merge( this.constructor(), elems );

	ret.prevObject = this;
	ret.context = this.context;

	return ret;
},

each: function( callback, args ) {
	//调用each工具方法 循环
	return jQuery.each( this, callback, args );
},

ready: function( fn ) {
	//调用ready加载
	jQuery.ready.promise().done( fn );

	return this;
},

slice: function() {
	//$('div').slice(2,4) 选取所有div元素的第二个第三个入栈 
	return this.pushStack( core_slice.apply( this, arguments ) );
},

first: function() {
	//选取第一个原生对象
	return this.eq( 0 );
},

last: function() {
	//选取最后一个原生对象
	return this.eq( -1 );
},

eq: function( i ) {
	//将第i个元素入栈 选取第i个元素对象
	var len = this.length,
		j = +i + ( i < 0 ? len : 0 );
	return this.pushStack( j >= 0 && j < len ? [ this[j] ] : [] );
},

map: function( callback ) {
	return this.pushStack( jQuery.map(this, function( elem, i ) {
		return callback.call( elem, i, elem );
	}));
},

end: function() {
	//寻找刚入栈的元素的前一个入栈的元素
	return this.prevObject || this.constructor(null);
},

push: core_push,
sort: [].sort,
splice: [].splice
}; 




//五：(285-347) jQuery.extend = jQuery.fn.extend = function(){xxx} 定义JQ的继承方法extend
后续扩展工具方法就用jQuery.extend({xxx}) 扩展实例方法就用jQuery.fn.extend({xxx})
1：应用$.extend方法 将第二个到最后一个参数的对象扩展到第一个参数a对象上
var a = {};
$.extend(a, {name: 'luo'}, {showName:function(){alert('luo')}});
console.log(a);		//{ name="luo", showName=function() } a对象被扩展了
a.showName();		//弹出 luo 相对于a对象继承了showName方法
相当于a对象继承了第二个第三个参数对象 所以可以用$.extend()模拟继承


2：$.extend模拟继承的浅拷贝 
var aaa = {};
var bbb = {name: {firstName:'luo'}}		//被拷贝(被继承)对象2层以上的对象嵌套
$.extend(aaa, bbb);
aaa.name.firstName = 'luo11111';		//修改子类
alert(aaa.name.firstName);				//luo11111 子类正常
alert(bbb.name.firstName);				//luo11111 子类影响了父类 不正常
如果被拷贝(被继承)对象有2层以上的对象嵌套 那extend过程中子类修改后会影响父类 因为extend默认就是浅拷贝
为了子类修改后不影响父类 需要使用深拷贝模式 把extend()方法的第一个参数设置为true就是启动深拷贝


3：$.extend模拟继承的深拷贝 
var ccc = {};
var ddd = {name: {firstName:'luo'}}		//被拷贝(被继承)对象2层以上的对象嵌套
$.extend(true, ccc, ddd);				//第一个参数设置为true 启动深拷贝
ccc.name.firstName = 'luo11111';		//修改子类
alert(ccc.name.firstName);				//luo11111 子类正常
alert(ddd.name.firstName);				//luo 子类没有影响父类 正常


4：如果$.extend()只有一个参数对象 那就是把这个参数对象扩展到jQuery对象上 就是添加jQuery工具方法
$.extend({say:function(){alert('我是工具方法插件')}});
$.say();			//弹窗 我是工具方法插件 添加了jQuery的工具方法


5：如果$.fn.extend()只有一个参数对象 那就是扩展到jQuery.fn对象
而jQuery.fn = jQuery.fn.init.prototype 所以就是扩展到实例化$(xxx)对象上 就是添加了jQuery实例方法 
$.fn.extend({say:function(){alert('我是实例方法插件')}});
$().say();			//弹窗 我是实例方法插件 添加了jQuery的实例方法


6：(285-347) 源码具体分析
jQuery.extend = jQuery.fn.extend = function() {
	var options, name, src, copy, copyIsArray, clone,
		target = arguments[0] || {},	//初始target是第一个参数 
		i = 1,			//定义后续循环的起始数 默认从1开始循环
		length = arguments.length,		
		deep = false;	//是否深拷贝 默认浅拷贝

	//如果arguments[0]是布尔值 也就是$.extend(true,{xx},{xx})的写法 说明是要进行深拷贝
	if ( typeof target === "boolean" ) {
		deep = target;		//把deep变为true 启动深拷贝
		target = arguments[1] || {};	//被扩展对象target变为第二个参数
		i = 2;				//循环起始数改为2
	}

	//被扩展对象target必须是对象
	if ( typeof target !== "object" && !jQuery.isFunction(target) ) {
		target = {};
	}

	//如果arguments.length是1(i默认是1) 那被扩展对象就是jQuery 也就是插件模式
	if ( length === i ) {
		target = this;
		--i;
	}

	//开始循环 如果是浅拷贝那i就是默认的1 从第二个参数(arguments[1])开始循环到arguments.length
	//如果是深拷贝那i被修改为2 从第三个参数(arguments[2])开始循环到arguments.length
	for ( ; i < length; i++ ) {
		if ( (options = arguments[ i ]) != null ) {
			//for in每个arguments[i]对象 
			for ( name in options ) {
				src = target[ name ];
				copy = options[ name ];

				//防止$.extend(a, {name:a})此种类型的对象引用死循环
				if ( target === copy ) {
					continue;
				}

				//deep为true并且copy存在 并且copy(也就是options[name])也是对象或对象数组 进行深拷贝处理 
				if ( deep && copy && ( jQuery.isPlainObject(copy) || (copyIsArray = jQuery.isArray(copy)) ) ) {
					if ( copyIsArray ) {
						copyIsArray = false;
						clone = src && jQuery.isArray(src) ? src : [];

					} else {
						clone = src && jQuery.isPlainObject(src) ? src : {};
					}

					target[ name ] = jQuery.extend( deep, clone, copy );

				//默认的浅拷贝处理
				} else if ( copy !== undefined ) {
					//target[name] = arguments[i][name] 拷贝继承 最终把每个arguments[i]扩充到target对象上  
					target[ name ] = copy;
				}
			}
		}
	}

	//最终返回被扩展完的对象target 	
	return target;
}; 



//六：(349-817) 扩展一些工具方法 $.xxx
1：工具方法不仅可以给$对象用 也可以给jQuery内部用(所以可以说工具方法是构建整个jQuery的基石) 
而且工具方法还可以给原生JS对象用 工具方法就相当于定义的全局函数

2：(349-817) 大致结构
jQuery.extend({
	expando: 生成唯一的JQ字符串(内部)
	noConflict()：防止$ jQuery冲突
	isReady：DOM是否加载完毕(内部)
	readyWait：等待多少文件的加计数器(内部)
	holdReady()：推迟DOM触发
	ready()：贮备DOM触发
	isFunction()：是否为函数
	isWindow()：是否为window
	isNumeric()：是否为数字
	type()：判断数据类型
	isPlainObject()：是否为对象字面量{}
	isEmptyObject(): 是否为空对象
	error()：抛出异常
	parseHTML()：解析HTML节点
	parseJSON()：解析JSON
	parseXML()：解析XML
	noop()：空函数
	globalEval()：全局解析JS
	camelCase()：转驼峰
	nodeName()：是否为指定节点名(内部)
	each()：遍历集合
	trim()：去前后空格
	makeArray()：类数组转真数组
	inArray()：数组版indexOf
	merge(): 合并数组
	grep()：过滤新数组
	map()：映射新数组
	guid：唯一标识符(内部)
	proxy()：改变this指向
	access(): 多功能值操作(内部)
	now()：当前时间
	swap()：css交换(内部)
});


3：(351) expando:"jQuery" + ( core_version + Math.random() ).replace( /\D/g, "" )
core_version=2.0.30，Math.random()=0.9954942357181062，replace( /\D/g, "" )去掉小数点 .
最终$.expando形成唯一的字符串 jQuery203009954942357181062 


4：(353-363) noConflict 卸载$或者jQuery
假如在引入jQuery之前定义了var $ = 123; var jQuery = 456; 然后引入jQuery 
如果var aaa = noConflict() 那卸载$ 之后调用jQuery方法是aaa().css(xxx) $依然是之前定义的123
如果var aaa = noConflict(true) 那卸载$ 之后调用jQuery方法是aaa().css(xxx) jQuery依然是之前定义的456
noConflict: function( deep ) {
	//如果aaa = noConflict()  
	if ( window.$ === jQuery ) {
		//之前已通过_$ = window.$预存了$ 这里提取预存的$
		window.$ = _$;
	}
	//如果aaa = noConflict(true)
	if ( deep && window.jQuery === jQuery ) {
		//之前已通过_jQuery = window.jQuery预存了jQuery
		window.jQuery = _jQuery;
	}
	//返回值就是可以调用实例方法的对象
	return jQuery;
}


5：jQuery中的DOM加载
原生window.onload=function(){xx} 除了DOM加载完毕以外图片等也必须加载完毕了才触发函数
JQ中通过$(function(){xxx})实现DOM的加载 只要DOM加载完毕就能触发函数 提高了加载速度

$(function(){xxx})后执行如下代码(184)
else if ( jQuery.isFunction( selector ) ) {
	return rootjQuery.ready( selector );
}
也就是return出$(document).ready(function(){xxx}); 参考(866) rootjQuery = jQuery(document);

执行$(document).ready(function(){xxx});
就执行240行的ready方法(注意这个ready方法是实例方法 不是(382)的ready工具方法)
ready: function( fn ) {
	jQuery.ready.promise().done( fn );
	return this;
},

执行jQuery.ready.promise()就调用(819)
jQuery.ready.promise = function( obj ) {
	//readyList之前未定义 进入if后就定义了if 保证if内部代码只执行一次
	if ( !readyList ) {
		//定义readyList为延迟对象
		readyList = jQuery.Deferred();
		//如果document已加载完毕了
		if ( document.readyState === "complete" ) {
			//直接调用(382)的工具方法jQuery.ready()
			setTimeout( jQuery.ready );
		//如果DOM没有加载完毕
		} else {
			//绑定DOMContentLoaded load事件 触发completed回调函数 最终执行382行的工具方法jQuery.ready();
			document.addEventListener( "DOMContentLoaded", completed, false );
			window.addEventListener( "load", completed, false );
		}
	}
	return readyList.promise( obj );
};

completed回调函数
completed = function() {
	//如果DOMContentLoaded事件先触发 进入后就会取消掉load事件的绑定 
	//总之DOMContentLoaded或load只触发其中一个事件
	document.removeEventListener( "DOMContentLoaded", completed, false );
	window.removeEventListener( "load", completed, false );
	jQuery.ready();
};

执行(382)的工具方法jQuery.ready();
ready: function( wait ) {
	//对(373)的holdReady()方法处理 通过--jQuery.readyWait推迟DOM的加载
	if ( wait === true ? --jQuery.readyWait : jQuery.isReady ) {
		return;
	}
	jQuery.isReady = true;
	if ( wait !== true && --jQuery.readyWait > 0 ) {
		return;
	}
	//调用deferred.resolveWith(context,[args]) 触发延迟对象执行
	readyList.resolveWith( document, [ jQuery ] );
	//对$(document).on('ready', function(){xxx})写法的支持
	if ( jQuery.fn.trigger ) {
		jQuery( document ).trigger("ready").off("ready");
	}
}

(373) 推迟DOM加载的方法
holdReady: function( hold ) {
	//如果写$.holdReady(true) 那就jQuery.readyWait++ 推迟DOM的加载
	if ( hold ) {
		jQuery.readyWait++;
	//之后再写$.holdReady(flase) 那就jQuery.ready( true ) 把之前推迟的DOM加载释放出来
	} else {
		jQuery.ready( true );
	}
},
 

6: (409-466) 类型判断
isFunction: function( obj ) {
	//是否为函数
	return jQuery.type(obj) === "function";
},

isArray: Array.isArray,		//是否为数组

isWindow: function( obj ) {
	//如果obj是null或者undefined obj.window必定会报错 
	//所以下面写上obj != null && 可以屏蔽掉后面的报错 而null和undefined都等于null 所以返回flase
	//例如：alert((function(){return null === null.window})()); 报错
	//alert((function(){return null != null && null === null.window})()); 不报错 正常返回flase
	//如果obj不是null也不是undefined也不是window 那返回的是true&&false 最终返回false
	//如果obj是window window===window.window成立 返回true&&true 最终返回true
	return obj != null && obj === obj.window;
},

isNumeric: function( obj ) {
	//原生的typeof NaN时也返回number 所以这里做了改进
	return !isNaN( parseFloat(obj) ) && isFinite( obj );
},

type: function( obj ) {
	if ( obj == null ) {
		return String( obj );
	}
	//原生的typeof数组 日期等都会返回object 这里做了改进 
	//$.type([1,2,3]);就返回array,  $.type(new Date());就返回date
	//class2type[ core_toString.call(obj) ] 返回array date regExp等原生typeof判断不了的类型
	return typeof obj === "object" || typeof obj === "function" ?
		class2type[ core_toString.call(obj) ] || "object" :
		typeof obj;
},

上面的class2type[ core_toString.call(obj) ] 通过如下实现 
因为core_toString = class2type.toString, 所以core_toString.call(obj)就是class2type.toString.call(obj)
如果obj是Date对象那就返回[object Date] 然后下面(844行)进行遍历 class2type[object Date]就转换为date了
jQuery.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(i, name) {
	class2type[ "[object " + name + "]" ] = name.toLowerCase();
});

为何可以通过class2type.toString.call(obj)来返回[object Date] 从而判断date等类型？
数组对象.toString扩充作用域到obj 就可以返回obj的详细类型 
就类似instanceof或者constructor判断类型(但是这两张方法有一定兼容性问题 toString完全没有)
var arr = [1,2,3];
var obj = new Date();
alert(arr.toString.call(obj))		//[object Date]

isPlainObject: function( obj ) {
	//isPlainObject判断是否为对象字面量 (通过"{}"或者"new Object"创建的)
	//如果type不是object 或者是DOM元素 或者是window 都不算对象字面量
	if ( jQuery.type( obj ) !== "object" || obj.nodeType || jQuery.isWindow( obj ) ) {
		return false;
	}
	
	//array date等对象 type也是object 可他们不算对象字面量
	//window.location等window下的对象 也不算对象字面量
	try {
		if ( obj.constructor &&
				!core_hasOwn.call( obj.constructor.prototype, "isPrototypeOf" ) ) {
			return false;
		}
	} catch ( e ) {
		return false;
	}

	//除了以上都是对象字面量
	return true;
},

isEmptyObject: function( obj ) {
	//isEmptyObject判断是否为空对象 
	//例如数组或{}或构造函数内部无定义的属性或方法 这些都不能for in 所以都返回true
	var name;
	for ( name in obj ) {
		return false;
	}
	return true;
},

camelCase: function( string ) {
	//通过rmsPrefix = /^-ms-/, 把ms-转为-ms- 
	//然后通过rdashAlpha = /-([\da-z])/gi, fcamelCase = function( all, letter ) {return letter.toUpperCase();}
	//转驼峰式写法
	return string.replace( rmsPrefix, "ms-" ).replace( rdashAlpha, fcamelCase );
},

nodeName: function( elem, name ) {
	//判断name是不是elem的节点名称
	//nodeName(document.documentElement, 'html') 返回true
	return elem.nodeName && elem.nodeName.toLowerCase() === name.toLowerCase();
},


7：(561-608) each工具方法  
$.each([1,2,3], function(key,value){xxx}); 注意和实例方法$(xx).each(function(){xx})区别
each: function( obj, callback, args ) {
	var value,
		i = 0,
		length = obj.length,
		isArray = isArraylike( obj );
	
	//如果有第三个参数args 那就是内部调用
	if ( args ) {
		if ( isArray ) {
			for ( ; i < length; i++ ) {
				value = callback.apply( obj[ i ], args );

				if ( value === false ) {
					break;
				}
			}
		} else {
			for ( i in obj ) {
				value = callback.apply( obj[ i ], args );

				if ( value === false ) {
					break;
				}
			}
		}

	//如果没有第三个参数args 就是外部调用 我们使用的就是这种外部调用
	} else {
		//如果是数组 类数组等
		if ( isArray ) {
			//用for循环执行callback回调函数
			for ( ; i < length; i++ ) {
				//callback(i, arr[i])
				value = callback.call( obj[ i ], i, obj[ i ] );
				//循环完毕 退出
				if ( value === false ) {
					break;
				}
			}
		} else {
			//如果不是数组 是json等 for in
			for ( i in obj ) {
				//callback(key, value)
				value = callback.call( obj[ i ], i, obj[ i ] );
				//循环完毕 退出
				if ( value === false ) {
					break;
				}
			}
		}
	}

	return obj;
},

在上面工具方法$.each的基础上 再封装一层 形成了实例方法$(xx).each (236)
each: function( callback, args ) {
	//调用$.each obj是this
	return jQuery.each( this, callback, args );
},


8：(615-706) 数组操作 
merge合并数组或者类数组 例如merge([1,2,3], [a,b,c]) 返回[1,2,3,a,b,c]
merge: function( first, second ) {
	var l = second.length,
		i = first.length,
		j = 0;
	if ( typeof l === "number" ) {
		//如果是第二个参数是数组(数组就有.length) 那for循环 第二个数组元素逐一添加到第一个数组
		for ( ; j < l; j++ ) {
			first[ i++ ] = second[ j ];
		}
	} else {
		//如果第二个参数是类数组 用while逐一添加
		while ( second[j] !== undefined ) {
			first[ i++ ] = second[ j++ ];
		}
	}
	first.length = i;
	//最终返回合并好的第一个数组
	return first;
},


利用上面的merge方法 形成(615-630)$.makeArray 类数组及字符串等转数组
例如 $.makeArray(document.getElementsByTagName('div')) 类数组转为数组
makeArray: function( arr, results ) {
	//results内部调用参数 外部不需要 ret初始是数组
	var ret = results || [];
	if ( arr != null ) {
		//如果是类数组或者字符串等 通过merge把arr合并到最终返回的ret数组上
		if ( isArraylike( Object(arr) ) ) {
			//如果arr是字符串 就直接变成[arr]数组
			jQuery.merge( ret, typeof arr === "string" ? [ arr ] : arr);
		} else {
			core_push.call( ret, arr );
		}
	}

	return ret;
},


inArray 例如 $.iArray(2, [1,2,3]) 查询2是数组[1,2,3]的第几个元素 不是就返回-1
inArray: function( elem, arr, i ) {
	//core_indexOf = core_deletedIds.indexOf = [].indexOf (55行)
	//[].indexOf.call( arr, elem, i )
	return arr == null ? -1 : core_indexOf.call( arr, elem, i );
},


grep 筛选数组 组成新数组
//例如$.grep( [0,1,2], function(n,i){return n > 0;} ); 返回[1,2]
//例如$.grep( [0,1,2], function(n,i){return n > 0;} , true); 返回[0]
grep: function( elems, callback, inv ) {
	var retVal,
		ret = [],
		i = 0,
		length = elems.length;.
		//假如参数inv没有写 也就是undifined 经过!!变为false
		inv = !!inv;

	for ( ; i < length; i++ ) {
		//执行回调函数 结果给到retVal retVal就是ture或者false
		retVal = !!callback( elems[ i ], i );
		//假如参数inv没有定义或者是false 而且上面回调函数结果retVal又是true
		if ( inv !== retVal ) {
			//那就会把当前循环得到的elem[i]push到结果数组ret里 最终返回ret
			ret.push( elems[ i ] );
		}
	}

	return ret;
},


$.map  根据回调callback修改原数组elems 记得区别于$().map
例子1  $.map( [0,1,2], function(n){return n + 4;});  返回[4, 5, 6]
例子2  $.map( [0,1,2], function(n){return n > 0 ? n + 1 : null;});  返回[1,2]
例子3  $.map( [0,1,2], function(n){return [ n, n + 1 ];});  返回[0, 1, 1, 2, 2, 3]
map: function( elems, callback, arg ) {		//第三个参数arg内部使用才需要写
	var value,
		i = 0,
		length = elems.length,
		isArray = isArraylike( elems ),
		ret = [];

	//如果是数组 用for
	if ( isArray ) {
		for ( ; i < length; i++ ) {
			//value等于此次循环执行callback的结果 如例子1
			value = callback( elems[ i ], i, arg );
			//如果结果不是null就把value push到最终返回数组ret
			//如果是null 如例子2 这个value就不push进去
			if ( value != null ) {
				//相当于push
				ret[ ret.length ] = value;
			}
		}

	//如果是类数组 用for in
	} else {
		for ( i in elems ) {
			value = callback( elems[ i ], i, arg );

			if ( value != null ) {
				ret[ ret.length ] = value;
			}
		}
	}

	//避免形成多维数组 例如例子3最终返回还是一维数组
	return core_concat.apply( [], ret );
},


9：(713-738) proxy 
用法1：变更作用域 show1函数的作用域从window变到document
function show1(){
	alert(this);
}
// $.proxy(show1, document)();			//所以这里弹出object HTMLDocument 而不是window了

用法2：变更作用域并且传入参数
function show2(n1, n2){
	alert(this);
	// alert(n1);
	// alert(n2);
}
// $.proxy(show2, document)(1, 2);		//写法1 弹出object HTMLDocument 1 2
// $.proxy(show2, document, 1)(2);		//写法2 弹出object HTMLDocument 1 2

用法3：变更作用域 show2作用域从document变成obj
obj = {
	show3: function(){
		alert(this);
	}
}
// $(document).click(obj.show3);				//直接调用obj.show3 由于click事件 所以弹出objectHTMLDocument
// $(document).click($.proxy(obj.show3, obj));	//proxy变更作用域到obj 弹出object Object
// $(document).click($.proxy(obj, 'show3'));	//上面的简写方式


(713-738) proxy的源码实现
proxy: function( fn, context ) {
	var tmp, args, proxy;

	//对应上面的用法3的简写方式 把$.proxy(obj, 'show3')转换回$.proxy(obj.show3, obj)
	if ( typeof context === "string" ) {
		//tmp = obj.show3
		tmp = fn[ context ];
		//context = obj
		context = fn;
		//fn = obj.show3
		fn = tmp;
	}

	//fn如果不是函数 
	if ( !jQuery.isFunction( fn ) ) {
		return undefined;
	}

	//对应用法2的写法2情况 转换为写法1 见下面的详细分析
	args = core_slice.call( arguments, 2 );
	proxy = function() {
		return fn.apply( context || this, args.concat( core_slice.call( arguments ) ) );
	};

	//唯一标示符guid 保证解绑事件等操作时 解绑唯一对应的对象事件
	proxy.guid = fn.guid = fn.guid || jQuery.guid++;

	return proxy;
},

上面用法2的写法2是如何转换为写法1的？
args = core_slice.call( arguments, 2 );
对于上面的这句 通过54行core_slice = core_deletedIds.slice 以及47行core_deletedIds = []
得到args = [].slice.call(arguments, 2); 
通过alert(args)看出切出的就是写法2的第三个参数[1]
那为什么不直接args = arguments.slice(2); 而非要args = [].slice.call(arguments, 2);
因为arguments是类数组 不能执行.slice方法 所以需要[]冒充对象到arguments任何.slice(2)
proxy = function() {
	// 注意这里的arguments就变成了[2]的类数组 不是上面的[show2, document, 1]的类数组了
	// 因为这里这里再次定义proxy函数 他的argument是$.proxy(show2, document, 1)(arguments) 
	// 可以在源码中alert(arguments[0])看出是[2] 所以core_slice.call( arguments )是[2]
	// 然后下面fn.apply(context||this, [1].concat([2])) 最终写法2就等同于写法1 $.proxy(show2, document)(1, 2)
	return fn.apply( context || this, args.concat( core_slice.call( arguments ) ) );
};


10: (742-793)access 只用于源码内部使用
情况1：$('#div1').css('width'); 获取
情况2：$('#div1').css('width', '200px'); 设置
情况3：$('#div1').css({'width':'200px', 'height':'300px'}); 设置多个值
在css attr等方法中 经常会有上面的三种情况 在源码中将这三种情况的共性提取出来 统一到access方法中
便于在构建css等实例方法的时候 调用这个工具方法access

access源码分析
access: function( elems, fn, key, value, chainable, emptyGet, raw ) {
	var i = 0,
		length = elems.length,
		bulk = key == null;

	//如果是情况3：$('#div1').css({'width':'200px', 'height':'300px'}); 设置多个值
	if ( jQuery.type( key ) === "object" ) {
		chainable = true;
		for ( i in key ) {
			//回调
			jQuery.access( elems, fn, i, key[i], true, emptyGet, raw );
		}

	//如果是情况2：$('#div1').css('width', '200px'); 设置
	} else if ( value !== undefined ) {
		chainable = true;

		if ( !jQuery.isFunction( value ) ) {
			raw = true;
		}

		//没有key的情况
		if ( bulk ) {
			// Bulk operations run against the entire set
			if ( raw ) {
				fn.call( elems, value );
				fn = null;

			//有key的情况
			} else {
				bulk = fn;
				fn = function( elem, key, value ) {
					return bulk.call( jQuery( elem ), value );
				};
			}
		}

		if ( fn ) {
			for ( ; i < length; i++ ) {
				//循环调用
				fn( elems[i], key, raw ? value : value.call( elems[i], i, fn( elems[i], key ) ) );
			}
		}
	}

	return chainable ?
		elems :

			//如果是情况1：$('#div1').css('width'); 获取
			bulk ?
			fn.call( elems ) :
			length ? fn( elems[0], key ) : emptyGet;
},


11: (798-817) swap  源码内部使用
假如#div1的css是display:none 那原生JS获取他的width offsetTop等是获取不到的
但是在平常写jquery的时候 直接$('div1').width()又能获取到width 那是为什么？
因为在调用$('#div1').width()等方法的时候 
源码内部通过swap()瞬间将css从display:none变成了display:block;visiblility:hidden
这样就可以获取到width了 获取完width后 又瞬间把css变回到display:none
所以swap在源码内部的作用就是旧css交换为新css 获取某些属性值 获取完再交换回旧css

swap方法的源码分析
swap: function( elem, options, callback, args ) {
	var ret, name,
		old = {};

	//存储旧css 改成新css
	for ( name in options ) {
		old[ name ] = elem.style[ name ];
		elem.style[ name ] = options[ name ];
	}

	//获取需要的属性值
	ret = callback.apply( elem, args || [] );

	//改回旧css
	for ( name in options ) {
		elem.style[ name ] = old[ name ];
	}

	//返回需要的属性值
	return ret;
}




//七：回调对象 $.Callbacks()  

//一：$.callbacks()的应用
//1: add添加函数 fire全触发
function aaa() {
	alert(1);
}
function bbb() {
	alert(2);
}
var cb = $.Callbacks();		//C必须大写
cb.add(aaa);
cb.add(bbb);
cb.fire();					//依次弹出 1 2 观察者模式
cb.fire();                  //再依次弹出 1 2  


//2：add添加函数 fire全触发传参数
function aaa(n) {
	alert('aaa函数' + n);
}
function bbb(n) {
	alert('bbb函数' + n);
}
var cb = $.Callbacks();		 
cb.add(aaa);
cb.add(bbb);
cb.fire(111);					//依次弹出 aaa函数111 bbb函数111


//3：定义$.Callbacks(flag)的flag参数
// once: 确保这个回调列表只执行一次(像一个递延 Deferred). 
// memory: 保持以前的值和将添加到这个列表的后面的最新的值立即执行调用任何回调 (像一个递延 Deferred). 
// unique: 确保一次只能添加一个回调(所以有没有在列表中的重复). 
// stopOnFalse: 当一个回调返回false时 中断调用 
function aaa() {
	alert(1);
}
function bbb() {
	alert(2);
}
//如果不加'once' 那就依次弹出1(第一个fire)  1 2(第二个fire)
//如果加了'once' 那就是只执行第一个fire 只弹出1
var cb = $.Callbacks('once');		 
cb.add(aaa);
cb.fire();					 
cb.add(bbb);
cb.fire();

function aaa() {
	alert(1);
}
function bbb() {
	alert(2);
}
//如果不加'memory' 那只弹出1 cb.add(bbb)在fire下面
//如果加了'memory' 那依次弹出1 2 因为cb.fire()先不触发 等所有add完毕再触发
var cb = $.Callbacks('memory');		 
cb.add(aaa);
cb.fire();					 
cb.add(bbb);

function aaa() {
	alert(1);
}
function bbb() {
	alert(2);
}
//如果不加'unique' 那依次弹出1 1
//如果加了'unique' 那去除重复的cb.add(aaa) 只弹出1 
var cb = $.Callbacks('unique');		 
cb.add(aaa);				 
cb.add(aaa);
cb.fire();

function aaa() {
	alert(1);
	return false;
}
function bbb() {
	alert(2);
}
//如果不加'stopOnFalse' 那依次弹出1 2s
//如果加了'stopOnFalse' 执行aaa return了false然后就终止触发了 所以只弹出1 
var cb = $.Callbacks('stopOnFalse');		 
cb.add(aaa);				 
cb.add(bbb);
cb.fire();	

function aaa() {
	alert(1);
	return false;
}
function bbb() {
	alert(2);
}
//组合模式 只触发一次fire 并且记忆 所以一次弹出1 2
var cb = $.Callbacks('once memory');	
cb.add(aaa);				 
cb.fire();	
cb.add(bbb);
cb.fire();


//4：$.Callbacks()对象下的其他方法
function aaa() {
	alert(1);
	return false;
}
function bbb() {
	alert(2);
}
var cb = $.Callbacks();	
cb.add(aaa);				 
cb.add(bbb);
cb.has(aaa);		//判断函数列表是否有aaa函数	
cb.remove(aaa);		//把aaa函数从函数列表移除
cb.empty();			//把所有的函数从函数列表移除
cb.disable();		//禁用函数列表
cb.lock(aaa);		//锁定aaa函数
cb.locked();		//判断aaa函数是否锁定
cb.fired() 			//是否在之前至少一次fire()过		   
cb.fire();


//二：(2880-3042) Callbacks的源码分析
//1：大致流程：
//var cb = $.Callbacks()后 jQuery.Callbacks执行完毕return self; self对象下有add fire remove等方法
//然后add(aaa); add(bbb); add(ccc) 将aaa bbb ccc函数存入到jQuery.Callbacks的list数组里面
//然后fire() 依次将数组list里面存入的函数一个个执行 完成全触发

//2：具体分析：
jQuery.Callbacks = function( options ) {
	//options可能是空 可能是'once'单个flag情况 可能是'once memory'组合模式情况
	//如果是空那就jQuery.extend({}, options) 最终options = {};
	//然后先看2847-2856
	// var optionsCache = {};
	// function createOptions( options ) {
	// 	var object = optionsCache[ options ] = {};
	// 	jQuery.each( options.match( core_rnotwhite ) || [], function( _, flag ) {
	// 		object[ flag ] = true;
	// 	});
	// 	return object;
	// }
	//如果是'once'单个flag 那通过createOptions( options ) 最终options = {'once': true}
	//如果是'once memory'组合模式 那通过createOptions( options ) 最终options = {'once': true, 'memory':true}
	options = typeof options === "string" ?
		( optionsCache[ options ] || createOptions( options ) ) :
		jQuery.extend( {}, options );

	var memory, fired, firing, firingStart, firingLength, firingIndex, list = [], stack = !options.once && [],
		//定义函数function fire(data){xxxx}; 触发的具体执行过程
		fire = function( data ) {
			memory = options.memory && data;
			fired = true;
			firingIndex = firingStart || 0;
			firingStart = 0;
			firingLength = list.length;
			firing = true;
			for ( ; list && firingIndex < firingLength; firingIndex++ ) {
				//循环 依次触发list数组存入的函数aaa bbb ccc
				if ( list[ firingIndex ].apply( data[ 0 ], data[ 1 ] ) === false && options.stopOnFalse ) {
					memory = false;  
					break;
				}
			}
			firing = false;
			if ( list ) {
				if ( stack ) {
					if ( stack.length ) {
						//如果once
						fire( stack.shift() );
					}
				} else if ( memory ) {
					//如果'memory'
					list = [];
				} else {
					self.disable();
				}
			}
		},
		//定义self对象
		self = {
			//add方法
			add: function() {
				if ( list ) {
					var start = list.length;
					//执行add(aaa) add(bbb) add(ccc)
					(function add( args ) {
						jQuery.each( args, function( _, arg ) {
							var type = jQuery.type( arg );
							if ( type === "function" ) {
								if ( !options.unique || !self.has( arg ) ) {
									//将aaa bbb ccc函数依次push到List数组里
									list.push( arg );
								}
							} else if ( arg && arg.length && type !== "string" ) {
								add( arg );
							}
						});
					})( arguments );
					if ( firing ) {
						firingLength = list.length;
					} else if ( memory ) {
						firingStart = start;
						fire( memory );
					}
				}
				return this;
			},
			//remove方法
			remove: function() {
				if ( list ) {
					jQuery.each( arguments, function( _, arg ) {
						var index;
						while( ( index = jQuery.inArray( arg, list, index ) ) > -1 ) {
							list.splice( index, 1 );
							if ( firing ) {
								if ( index <= firingLength ) {
									firingLength--;
								}
								if ( index <= firingIndex ) {
									firingIndex--;
								}
							}
						}
					});
				}
				return this;
			},
			//has方法
			has: function( fn ) {
				return fn ? jQuery.inArray( fn, list ) > -1 : !!( list && list.length );
			},
			//empty方法
			empty: function() {
				list = [];
				firingLength = 0;
				return this;
			},
			//disable方法
			disable: function() {
				list = stack = memory = undefined;
				return this;
			},
			//disabled方法
			disabled: function() {
				return !list;
			},
			//lock方法
			lock: function() {
				stack = undefined;
				if ( !memory ) {
					self.disable();
				}
				return this;
			},
			//locked方法
			locked: function() {
				return !stack;
			},
			//fireWith方法
			fireWith: function( context, args ) {
				if ( list && ( !fired || stack ) ) {
					args = args || [];
					args = [ context, args.slice ? args.slice() : args ];
					if ( firing ) {
						stack.push( args );
					} else {
						//进入fireWith方法后 调用上面定义的fire函数 进行触发具体执行
						fire( args );
					}
				}
				return this;
			},
			//fire方法 
			fire: function() {
				//调用fire方法后 进入上面的fireWith方法
				self.fireWith( this, arguments );
				return this;
			},
			//fired方法
			fired: function() {
				return !!fired;
			}
		};

	//最终返回self对象 所以$.Callbacks()就是slef对象 最终使用就是$.Callbacks().add(xxx)等
	return self;
};



//八：延迟对象 $.Deferred() ----------------------------------------------

//一：$.Deferred()的应用
//1: done配合resolve就相当于回调对象的fire配合add
var dfd = $.Deferred();
setTimeout(function(){
	alert(11);
	dfd.resolve();		//执行成功触发
}, 1000);
dfd.done(function(){	//执行成功触发的函数
	alert(22);
});

//2: done配对resolve fail配对reject progress配对notify
var dfd = $.Deferred();
setTimeout(function(){
	alert(11);
	dfd.notify();			//执行过程中触发
	// dfd.resolve();		//执行成功
	// dfd.reject();		//执行失败触发
}, 1000);
dfd.done(function(){
	alert('执行成功');    	//执行成功触发的函数
}).fail(function(){
	alert('执行失败');		//执行失败触发的函数
}).progress(function(){		
	alert('执行中');		//执行过程中触发的函数
});

//3：把上面应用到延迟进程中 比如ajax请求过程中 不需要resolve notify reject触发
$.ajax('xxx.php')
	.done(function(){alert('请求完毕并成功')})
	.fail(function(){alert('请求完毕并失败')})
	.progress(function(){alert('请求过程中')});

//4：notify会多次触发  resolve reject只会触发一次
var dfd = $.Deferred();
setInterval(function(){		//定时器
	alert(11);
	dfd.notify();			//触发多次	 
}, 1000);
dfd.done(function(){
	alert('执行成功');    	//执行成功触发的函数
}).fail(function(){
	alert('执行失败');		//执行失败触发的函数
}).progress(function(){		
	alert('执行中');		//执行过程中触发的函数
});

//5: notify resolve reject都带回调对象的"memory"功能
//先弹11 然后如果点击了input就弹22 否则不弹
var dfd = $.Deferred();
setTimeout(function(){		 
	alert(11);
	dfd.notify();			 
}, 1000);

$('input').click(function(){
	dfd.done(function(){
		alert(22);    	 
	})
});

//6: always附加可选的一个函数 执行成功或者失败都会触发这个函数
var dfd = $.Deferred();
setTimeout(function(){		 
	alert(11);
	// dfd.resolve();	
	dfd.reject();		 
}, 1000);
dfd.always(function(){
	alert('执行成功或者失败');    //执行成功或者失败都会触发的函数
})

//7: then附加三个函数 依次执行成功失败进行中触发这三个函数
var dfd = $.Deferred();
setTimeout(function(){		 
	alert(11);
	dfd.notify();		 
}, 1000);
dfd.then(function(){
	alert('执行成功');    //相当于上面的2
},function(){
	alert('执行失败');
},function(){
	alert('执行中');
});


//二：Deferred源码分析
Deferred: function( func ) {
	var tuples = [
			//定义一个二维数组 形成resolve对应done reject对应fail notify对应progress
			//并且resolve及reject触发带回调对象Callbacks的once memory功能
			//notify不带once 会反复触发  
			[ "resolve", "done", jQuery.Callbacks("once memory"), "resolved" ],
			[ "reject", "fail", jQuery.Callbacks("once memory"), "rejected" ],
			[ "notify", "progress", jQuery.Callbacks("memory") ]
		],
		state = "pending",
		//定义promise对象 它下面有state always then promise方法
		promise = {
			state: function() {
				return state;
			},
			//alwas(fn)后 fn在成功及失败都会执行 等同于.done(fn).fail(fn) 
			always: function() {
				deferred.done( arguments ).fail( arguments );
				return this;
			},
			//then(fn1,fn2,fn3)等同于done(fn1).fail(fn2).progress(fn3)
			then: function() {
				var fns = arguments;
				return jQuery.Deferred(function( newDefer ) {
					jQuery.each( tuples, function( i, tuple ) {
						var action = tuple[ 0 ],
							fn = jQuery.isFunction( fns[ i ] ) && fns[ i ];
						deferred[ tuple[1] ](function() {
							var returned = fn && fn.apply( this, arguments );
							if ( returned && jQuery.isFunction( returned.promise ) ) {
								returned.promise()
									.done( newDefer.resolve )
									.fail( newDefer.reject )
									.progress( newDefer.notify );
							} else {
								newDefer[ action + "With" ]( this === promise ? newDefer.promise() : this, fn ? [ returned ] : arguments );
							}
						});
					});
					fns = null;
				}).promise();
			},
			//下面会执行promise.promise(deferred); 调用这个函数从而让promise对象扩展到deferred对象
			promise: function( obj ) {
				return obj != null ? jQuery.extend( obj, promise ) : promise;
			}
		},
		//定义deferred对象
		deferred = {};

	//promise对象下又多了个pipe方法
	promise.pipe = promise.then;

	//关键部分 遍历整个二维数组 形成$.Deferred()对象等同于$.Callbacks()对象功能
	jQuery.each( tuples, function( i, tuple ) {
		var list = tuple[ 2 ],
			stateString = tuple[ 3 ];

		//让promise[done|fail|progress]功能就等同于list.add 
		//此时promise对象下又多了done fail progress三个方法
		promise[ tuple[1] ] = list.add;
		
		//判断stateString状态 二维数组的第三个子数组的stateString是undefined
		if ( stateString ) {
			list.add(function() {
				state = stateString;
			}, tuples[ i ^ 1 ][ 2 ].disable, tuples[ 2 ][ 2 ].lock );
		}

		//让deferred[resolve|reject|notify]功能等同于回调对象下的fireWith
		//并且由于上面的二维数组对应 形成resolve对应done reject对应fail notify对应progress
		//并且deferred对象有了自己的resolve reject notify方法 因为tuple[0]就是resolve或reject或notify
		deferred[ tuple[0] ] = function() {
			deferred[ tuple[0] + "With" ]( this === deferred ? promise : this, arguments );
			return this;
		};
		deferred[ tuple[0] + "With" ] = list.fireWith;
	});

	//到现在为止promise对象下有state always then promise done fail progress这几个方法
	//promise方法是 promise:function(obj){return obj != null ? jQuery.extend(obj,promise ) : promise;}
	//就是把promise对象扩张到参数obj对象上去
	//下面调用promise对象下的promise方法 就是把promise对象下的方法全部扩张到deferred对象上去
	//所以现在的deferred对象具备了promise对象的所有方法并且还有自身的resolve reject notify方法
	promise.promise( deferred );

	if ( func ) {
		func.call( deferred, deferred );
	}

	//$.Deferred()的执行结果就是最终返回deferred对象
	//所以实际应用时可以用$.Deferred调用dnoe ntify then always等等上面的所有方法 
	return deferred;
},



//三：延迟对象扩展方法 $.when的应用
//情况1: when不传参数 只会执行done里面的函数
function aaa(){
	var dfd = $.Deferred();
	dfd.resolve();
	return dfd;
}
function bbb(){
	var dfd = $.Deferred();
	dfd.reject();
	return dfd;
}
$.when().done(function(){
	alert('成功');
}).fail(function(){
	alert('失败');
});

//情况2：when只传一个延迟对象参数 
//延迟对象resolve就执行done reject就执行fail progress就执行notity
function aaa(){
	var dfd = $.Deferred();
	dfd.resolve();
	return dfd;
}
function bbb(){
	var dfd = $.Deferred();
	dfd.reject();
	return dfd;
}
$.when(aaa()).done(function(){	//因为aaa()内部是resolve 所以这里指向done里的弹出成功
	alert('成功');
}).fail(function(){
	alert('失败');
});

//情况3：when传多个延迟对象参数 如果某个延迟对象参数有reject就执行fail 
//没有reject但是有notity就执行progress 也没有notify全部是reslove才执行done() 
function aaa(){
	var dfd = $.Deferred();
	dfd.resolve();
	return dfd;
}
function bbb(){
	var dfd = $.Deferred();
	dfd.reject();
	return dfd;
}
function ccc(){
	var dfd = $.Deferred();
	dfd.notify();
	return dfd;
}
$.when(aaa(), bbb(), ccc()).done(function(){	 
	alert('成功');
}).fail(function(){
	alert('失败');
}).progress(function(){
	alert('进行中');
});

//情况4：when部分参数是非延迟对象 忽略掉非延迟对象
function aaa(){
	var dfd = $.Deferred();
	dfd.resolve();
	return dfd;
}
function bbb(){
	var dfd = $.Deferred();
	dfd.reject();
	return dfd;
}
function ccc(){
	var dfd = $.Deferred();
	dfd.notify();
	return dfd;
}
//因为这里忽略掉了111 222 只管aaa() bbb() 所以是进行中
$.when(aaa(), ccc(), 111, 222).done(function(){	 
	// arguments[2]		//传入非延迟对象的唯一意义就是接收参数
	// arguments[3]
	alert('成功');
}).fail(function(){
	alert('失败');
}).progress(function(){
	alert('进行中');
});


//四：when源码分析
when: function( subordinate /* , ..., subordinateN * ) {
	var i = 0,
		//arguments是when()的参数 是一个类数组 
		//所以用core_slice.call(arguments)=[].call(arguments)变成真正的数组
		resolveValues = core_slice.call( arguments ),
		//记录有几个参数
		length = resolveValues.length,

		//情况1：没有参数length=0 length!==1是ture 所以remaining=length=0
		//情况2：传入一个延迟对象length=1 
		//subordinate && jQuery.isFunction( subordinate.promise )是true 所以remaining=length=1
		//情况3：假如传入3个延迟对象length=3 length!==1是ture 所以remaining=length=3
		//情况4：假如共传入4个参数length=4 length!==1是ture 所以remaining=length=4
		remaining = length !== 1 || ( subordinate && jQuery.isFunction( subordinate.promise ) ) ? length : 0,

		//情况1: 因为remaining==0 所以deferred=jQuery.Deferred()
		//情况2: 因为remaining==1 所以deferred=subordinate 也就是第一个延迟对象参数
		//情况3: 因为remaining==3 所以deferred=jQuery.Deferred()
		//情况3: 因为remaining==4 所以deferred=jQuery.Deferred()
		deferred = remaining === 1 ? subordinate : jQuery.Deferred(),

		//情况4：忽略非延迟对象 remaining计数器减1
		updateFunc = function( i, contexts, values ) {
			return function( value ) {
				contexts[ i ] = this;
				values[ i ] = arguments.length > 1 ? core_slice.call( arguments ) : value;
				if( values === progressValues ) {
					deferred.notifyWith( contexts, values );
				} else if ( !( --remaining ) ) {
					deferred.resolveWith( contexts, values );
				}
			};
		},

		progressValues, progressContexts, resolveContexts;

	//情况1：不执行这里
	//情况2：不执行这里
	//情况3：如果某个延迟对象参数有reject就执行fail 
	//没有reject但是有notity就执行progress 也没有notify只有reslove才执行done()  
	//情况4：updateFunc的时候自动过滤掉非延迟对象
	if ( length > 1 ) {
		progressValues = new Array( length );
		progressContexts = new Array( length );
		resolveContexts = new Array( length );
		for ( ; i < length; i++ ) {
			if ( resolveValues[ i ] && jQuery.isFunction( resolveValues[ i ].promise ) ) {
				resolveValues[ i ].promise()
					.done( updateFunc( i, resolveContexts, resolveValues ) )
					.fail( deferred.reject )
					.progress( updateFunc( i, progressContexts, progressValues ) );
			} else {
				--remaining;
			}
		}
	}

	//情况1: 执行这里 进行resloveWith
	//情况2: 不执行这里
	//情况3: 不执行这里
	//情况4: 不执行这里
	if ( !remaining ) {
		deferred.resolveWith( resolveContexts, resolveValues );
	}

	//情况1：执行done内的函数
	//情况2：延迟对象resolve就执行done reject就执行fail progress就执行notity
	//情况3：如果某个延迟对象参数有reject就执行fail 
	//没有reject但是有notity就执行progress 也没有notify只有reslove才执行done
	//情况4：updateFunc的时候自动过滤掉非延迟对象 留下延迟对象
	return deferred.promise();
}






//九：(3184-3295) support 功能检测

//一：概述
//1：大概结构
//匿名函数自我执行接收参数{}给参数support，最终返回这个support，然后赋值给$.support
//所以$.support是一个json对象 可以通过console.log($.support)查看
$.support = ( function( support ) {
	xxxx;
	return support;
} )( {} );*/
// console.log($.support);

//2：作用
$.support主要用于jQuery内部的功能检测 如果不具备某种功能再用jQuery.valHooks做相应的兼容处理


//二：$.support源码分析
jQuery.support = (function( support ) {
	var input = document.createElement("input"),
		fragment = document.createDocumentFragment(),
		div = document.createElement("div"),
		select = document.createElement("select"),
		opt = select.appendChild( document.createElement("option") );

	//基本所有浏览器document.createElement("input").type都有默认值'text' 这句没什么意义
	if ( !input.type ) {
		return support;
	}
	
	//然后把type改为"checkbox"
	input.type = "checkbox";
	
	//用如下测试代码
	//var input = document.createElement("input");
	//input.type="checkbox"
	//alert(input.value);
	//低版本safari会弹出"" 所以support.checkOn是flase 其他浏览器会弹出"on" 所以support.checkOn是true
	support.checkOn = input.value !== "";

	//IE下opt.selected是flase 其他是true
	support.optSelected = opt.selected;

	//初始值 因为这三个要等页面加载完才能判断 所以在下面的$(function(){xxx})里面再判断赋值
	support.reliableMarginRight = true;
	support.boxSizingReliable = true;
	support.pixelPosition = false;

	//IE下复制的节点.checked是flase 其他是true
	input.checked = true;
	support.noCloneChecked = input.cloneNode( true ).checked;

	//老版本WebKit下select被禁止 它的options也会被禁止 所以返回false
	select.disabled = true;
	support.optDisabled = !opt.disabled;

	//IE下线设置value为"t" 再将input类型从默认的"text"变成"radio" value会变成"on"而不是"t" 所以返回false
	input = document.createElement("input");
	input.value = "t";
	input.type = "radio";
	support.radioValue = input.value === "t";

	//老版本WebKit返回false
	input.setAttribute( "checked", "t" );
	input.setAttribute( "name", "t" );
	fragment.appendChild( input );
	support.checkClone = fragment.cloneNode( true ).cloneNode( true ).lastChild.checked;

	//除了IE支持onfocusin返回true 其他都是false
	support.focusinBubbles = "onfocusin" in window;
	div.style.backgroundClip = "content-box";
	div.cloneNode( true ).style.backgroundClip = "";
	support.clearCloneStyle = div.style.backgroundClip === "content-box";

	//某些功能检测必须DOM加载完毕后才能检测，所以下面的代码用$(function(xxx))包裹，在DOM加载完毕后执行
	jQuery(function() {
		var container, marginDiv,
			//content-box区分标准模式 怪异模式
			divReset = "padding:0;margin:0;border:0;display:block;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box",
			body = document.getElementsByTagName("body")[ 0 ];

		if ( !body ) {
			//框架模式没有body
			return;
		}

		//创建父div及样式(标准模式) 子div及样式(怪异模式) 为后续判断准备
		container = document.createElement("div");
		container.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px";
		body.appendChild( container ).appendChild( div );
		div.innerHTML = "";
		div.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%";

		//通过swap进行css瞬间交换 判断support.boxSizing 低版本IE返回flase 其他都true
		jQuery.swap( body, body.style.zoom != null ? { zoom: 1 } : {}, function() {
			support.boxSizing = div.offsetWidth === 4;
		});

		// Use window.getComputedStyle because jsdom on node.js will break without it.
		if ( window.getComputedStyle ) {
			//低版本safari support.pixelPosition返回false 其他true
			support.pixelPosition = ( window.getComputedStyle( div, null ) || {} ).top !== "1%";
			//IE返回false 其他true
			support.boxSizingReliable = ( window.getComputedStyle( div, null ) || { width: "4px" } ).width === "4px";

			marginDiv = div.appendChild( document.createElement("div") );
			marginDiv.style.cssText = div.style.cssText = divReset;
			marginDiv.style.marginRight = marginDiv.style.width = "0";
			div.style.width = "1px";
			//低版本webkit返回false 其他true
			support.reliableMarginRight =
				!parseFloat( ( window.getComputedStyle( marginDiv, null ) || {} ).marginRight );
		}

		body.removeChild( container );
	});

	return support;
})( {} ); 




});